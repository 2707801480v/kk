export const routeMap = {
    homepage: '/',
    courseResources: '/course-resources',
    functionUsage: '/function-usage',
    contactUs: '/contact-us',
    login: '/login',
    register: '/register',
    personalInfo: '/personal-information',
    textGeneratedImages: '/text-generated-images',
    imageGeneratedImage: '/image-generated-image',
    courseDetails: '/course-details',
    courseSelection: '/course-selection',
    account: '/account',
    chatgpt: '/chat-gpt'
}