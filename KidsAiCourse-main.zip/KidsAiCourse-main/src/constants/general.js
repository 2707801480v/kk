export const chatgptContent = 'As your intelligent partner, I can not only write copy and come up with ideas, but also chat and answer questions with you. Want to know what else I can do? Click here to get started quickly! You can collect the official website address of ERNIE Bot in the browser, which will be more efficient next time ~';

export const helloAI = "Hello, I am a teenage AI";

// modelslab key
export const modelsLabKey = 'VM5JdBeglGFgxjKr6UgkPxsAmbWVbQchSqf4x4pqUzRX3z7UYl0N4DGAloGH';