import ModelSelectionCard from "./ModelSelection";
import { Autocomplete, Card, InputAdornment, List, ListItem, ListItemText, TextField } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import React from "react";
import styles from './GptHistory.module.css';

function GptHistory({ searchHistory, onSelectChat }) {
    return (
        <Card>
            <ModelSelectionCard />
            <div className={styles.searchWrapper}>
                <Autocomplete
                    freeSolo
                    disableClearable
                    options={[]}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            label="Search History"
                            InputProps={{
                                ...params.InputProps,
                                type: 'search',
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchIcon />
                                    </InputAdornment>
                                ),
                            }}
                        />
                    )}
                    sx={{ width: 350 }}
                />
            </div>
            <div className={styles.list}>
                <List>
                    {searchHistory.map((item, index) => (
                        <ListItem key={index} button onClick={() => onSelectChat(item.id)} disablePadding>
                            <ListItemText primary={item.title} />
                        </ListItem>
                    ))}
                </List>
            </div>
        </Card>
    );
}

export default GptHistory