// GeneratePageHistory.js
import React, { useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
import { Autocomplete, InputAdornment, TextField, List, ListItem, ListItemText } from '@mui/material';
import styles from './GeneratePageHistory.module.css';

function GeneratePageHistory({ searchHistory, onSelectHistoryItem }) {
    const [searchQuery, setSearchQuery] = useState('');

    const handleClick = (historyItem) => {
        onSelectHistoryItem(historyItem);
    };

    const handleSearch = (event, value) => {
        setSearchQuery(value);
    };

    const filteredHistory = searchHistory.filter((item) =>
        item.prompt.toLowerCase().includes(searchQuery.toLowerCase()) &&
        item.generatedImage !== ''
    );

    return (
        <div>
            <div className={styles.searchWrapper}>
                <Autocomplete
                    freeSolo
                    disableClearable
                    options={searchHistory.map((item) => item.prompt)}
                    onInputChange={handleSearch}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            label="Search History"
                            InputProps={{
                                ...params.InputProps,
                                type: 'search',
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchIcon />
                                    </InputAdornment>
                                ),
                            }}
                        />
                    )}
                    sx={{ width: 350 }}
                />
            </div>
            {filteredHistory.length > 0 && (
                <div className={styles.list}>
                    <List>
                        {filteredHistory.slice().map((item, index) => (
                            <ListItem key={index} button onClick={() => handleClick(item)} disablePadding>
                                <ListItemText primary={item.prompt} />
                            </ListItem>
                        ))}
                    </List>
                </div>
            )}
        </div>
    );
}

export default GeneratePageHistory;