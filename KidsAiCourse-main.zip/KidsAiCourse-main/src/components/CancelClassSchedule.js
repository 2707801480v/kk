import React, { useState, useCallback } from 'react';
import {
    LocalizationProvider,
    DateRangePicker
} from '@mui/x-date-pickers-pro';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import {
    TextField,
    Box,
    Button,
    Typography,
    Card,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle
} from '@mui/material';
import {
    startOfWeek,
    endOfWeek,
    isWithinInterval,
    addWeeks,
    subWeeks,
    format
} from 'date-fns';
import ClassSchedule from './ClassSchedule';


function WeekRangePicker({ value, onChange }) {

    const handleDateChange = (newValue) => {
        if (newValue[0]) {
            const weekStart = startOfWeek(newValue[0], { weekStartsOn: 1 });
            const weekEnd = endOfWeek(weekStart, { weekStartsOn: 1 });
            onChange([weekStart, weekEnd]);
        } else {
            onChange([null, null]);
        }
    };

    const isDateDisabled = (date) => {
        if (!value[0]) return false;
        const weekStart = startOfWeek(value[0], { weekStartsOn: 1 });
        const weekEnd = endOfWeek(weekStart, { weekStartsOn: 1 });
        return !isWithinInterval(date, { start: weekStart, end: weekEnd });
    };

    return (
        <DateRangePicker
            value={value}
            onChange={handleDateChange}
            renderInput={(startProps, endProps) => (
                <>
                    <TextField {...startProps} />
                    <Box sx={{ mx: 2 }}> to </Box>
                    <TextField {...endProps} />
                </>
            )}
            shouldDisableDate={isDateDisabled}
        />
    );
}

function CancelClassSchedule() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const userId = sessionStorage.getItem('userId');
    const [dateRange, setDateRange] = useState(() => {
        const today = new Date();
        const monday = startOfWeek(today, { weekStartsOn: 1 });
        const sunday = endOfWeek(today, { weekStartsOn: 1 });
        return [monday, sunday];
    });
    const [classes, setClasses] = useState([]);
    const [chosenClasses, setChosenClasses] = useState([]);
    const [open, setOpen] = useState(false);
    const [tempSelectedClass, setTempSelectedClass] = useState(null);

    const handlePreviousWeek = () => {
        setDateRange([subWeeks(dateRange[0], 1), subWeeks(dateRange[1], 1)]);
    };

    const handleNextWeek = () => {
        setDateRange([addWeeks(dateRange[0], 1), addWeeks(dateRange[1], 1)]);
    };

    const handleCellClick = (cls, isChosen) => {
        console.log("cls:", cls);
        if (isChosen) {
            setTempSelectedClass(cls);
            setOpen(true);
        }
    };

    const handleConfirm = async () => {
        if (tempSelectedClass) {
            try {
                const response = await fetch(`${baseUrl}/kidsai/userClass/save?classId=${encodeURIComponent(tempSelectedClass.id)}&userId=${encodeURIComponent(userId)}&isDelete=${encodeURIComponent(true)}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'include'
                });
                const data = await response.json();
                console.log("data:", data);
                if (response.status === 200) {
                    setOpen(false);
                    setChosenClasses(prevChosenClasses =>
                        prevChosenClasses.filter(id => id !== tempSelectedClass.id)
                    );
                    setClasses(prevClasses =>
                        prevClasses.map(cls =>
                            cls.id === tempSelectedClass.id
                                ? { ...cls, isDeleted: true }
                                : cls
                        )
                    );
                    alert("Class cancelled successfully");
                } else {
                    setOpen(false);
                    alert(data.message);
                }
            } catch (error) {
                setOpen(false);
                console.error("Error cancelling class:", error);
                alert("Failed to cancel class");
            } finally {
                setTempSelectedClass(null);
            }
        }
    };

    const handleClose = () => {
        setOpen(false);
        setTempSelectedClass(null);
    };

    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Card sx={{ width: '100%', maxWidth: 1200, p: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Button onClick={handlePreviousWeek}>Previous Week</Button>
                    <WeekRangePicker
                        value={dateRange}
                        onChange={(newRange) => {
                            setDateRange(newRange);
                        }}
                    />
                    <Button onClick={handleNextWeek}>Next Week</Button>
                </Box>
                <Typography variant="subtitle1" gutterBottom>
                    {format(dateRange[0], 'dd/MM/yyyy')} - {format(dateRange[1], 'dd/MM/yyyy')}
                </Typography>
                <ClassSchedule
                    flag={1}
                    startDate={format(dateRange[0], 'dd/MM/yyyy')}
                    endDate={format(dateRange[1], 'dd/MM/yyyy')}
                    setClasses={setClasses}
                    chosenClasses={chosenClasses}
                    setChosenClasses={setChosenClasses}
                    onCellClick={handleCellClick}
                    tooltipMessage="Click to cancel this class"
                    alwaysShowTooltip={true}
                />
                <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>Cancel Class</DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            Are you sure you want to cancel this class?
                            {tempSelectedClass && (
                                <>
                                    <br />
                                    {`Course: ${tempSelectedClass.name}`}
                                    <br />
                                    {`Location: ${tempSelectedClass.location}`}
                                    <br />
                                    {`Time: ${tempSelectedClass.startTime} - ${tempSelectedClass.endTime}`}
                                </>
                            )}
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleClose} color="primary">
                            Cancel
                        </Button>
                        <Button onClick={handleConfirm} color="primary">
                            Confirm
                        </Button>
                    </DialogActions>
                </Dialog>
            </Card>
        </LocalizationProvider>
    );
}

export default CancelClassSchedule;