import * as React from 'react';
import {routeMap} from "../routeMap";
import styles from './Header.module.css';
import {Link, Toolbar, Button, Typography, Menu, MenuItem,} from "@mui/material";
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import {useCallback, useContext, useEffect, useState} from "react";
import {UserContext} from "../context/UserContext";
import {useNavigate} from 'react-router-dom';
import ImportContactsRoundedIcon from "@mui/icons-material/ImportContactsRounded";

const headerContent = [
    {
        title: 'Course Resources',
        url: routeMap.courseResources
    },
    {
        title: 'Function Usage',
        url: routeMap.functionUsage,
        submenu: [
            {
                title: 'Text Generates Images',
                url: routeMap.textGeneratedImages
            },
            {
                title: 'Image Generates Images',
                url: routeMap.imageGeneratedImage
            },
            {
                title: 'Chat GPT',
                url: routeMap.chatgpt
            },
            {
                title: 'Contact Us',
                url: routeMap.contactUs
            }
        ]
    },
];

function Header() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const colors = ['#26a398', '#8ac94e', '#fa0', '#eb0001', '#238538', '#183f74'];
    const [courseList, setCourseList] = useState([]);
    const handleClassClick = (courseId) => {
        navigate(`/course-details/${courseId}`);
        handleClose();
    };

    const fetchData = useCallback(async (url, options = {}) => {
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                ...options
            });
            if (response.status === 200) {
                return await response.json();
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        } catch (error) {
            console.error(`Error fetching data from ${url}:`, error);
            return null;
        }
    }, []);

    useEffect(() => {
        const getCourseList = async () => {
            let url = `${baseUrl}/kidsai/course/findAll`;
            const data = await fetchData(url);
            if (data) setCourseList(data.result);
        };
        getCourseList();
    }, [baseUrl, fetchData]);

    const {user, setUser} = useContext(UserContext);
    const navigate = useNavigate();
    const [anchorEl, setAnchorEl] = useState(null);
    const [currentMenu, setCurrentMenu] = useState(null);

    const handleClick = (event, title) => {
        setAnchorEl(event.currentTarget);
        setCurrentMenu(title);
    };

    const handleClose = () => {
        setAnchorEl(null);
        setCurrentMenu(null);
    };

    const handleMenuClick = (url) => {
        handleNavigation(url);
        handleClose();
    };

    const handleNavigation = (url) => {
        navigate(url, {replace: true});
        handleClose();
    };

    const handleLogoutClick = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/auth/logout`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include',
            });
            if (response.ok) {
                const data = await response.json();
                if (data.code === '200') {
                    setUser({isLoggedIn: false});
                    document.cookie = "auth=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    sessionStorage.removeItem('userId');
                    window.location.href = routeMap.homepage;
                }
            } else {
                console.log("Call logout API failed.");
            }
        } catch (error) {
            console.error('Error fetching logout:', error);
        }
    };

    return (
        <div>
            <div className={styles.background}>
                <div className={styles.container}>
                    <Toolbar className={styles.toolbar}>
                        <div className={styles.logoPlaceholder} onClick={() => handleNavigation(routeMap.homepage)}>
                            <Typography variant="h4" component="span">Youth AI LOGO</Typography>
                        </div>
                        <div className={styles.menu}>
                            {headerContent.map(item => (
                                <div key={item.title} className={styles.title}>
                                    <Button
                                        color="inherit"
                                        onClick={(event) => handleClick(event, item.title)}
                                        className={styles.menuButton}
                                        disableRipple
                                    >
                                        {item.title}
                                        {currentMenu === item.title ? <KeyboardArrowUpIcon/> : <KeyboardArrowDownIcon/>}
                                    </Button>

                                    {currentMenu === "Function Usage" && item.submenu && (
                                        <Menu
                                            anchorEl={anchorEl}
                                            keepMounted
                                            open={currentMenu === item.title}
                                            onClose={handleClose}
                                            classes={{paper: styles.customMenu}}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                        >
                                            {item.submenu.map(subItem => (
                                                <MenuItem key={subItem.title} className={styles.menuItem}
                                                          onClick={() => handleMenuClick(subItem.url)}>
                                                    {subItem.title}
                                                    <div className={styles.menuLine}></div>
                                                </MenuItem>
                                            ))}
                                        </Menu>
                                    )}

                                    {currentMenu === "Course Resources" && (
                                        <Menu
                                            anchorEl={anchorEl}
                                            keepMounted
                                            open={currentMenu === item.title}
                                            onClose={handleClose}
                                            classes={{paper: styles.customMenu}}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                        >
                                            <Link className={styles.exploreAll} onClick={() => handleNavigation(routeMap.courseSelection)}>
                                                Explore All
                                            </Link>
                                            <div className={styles.courseWrapper} style={{ backgroundColor: courseList.length === 0 ? 'transparent' : '#fff' }}>
                                                {courseList.length > 0 ? (
                                                    courseList.map((course, index) => (
                                                        <MenuItem
                                                            key={course.id || index}
                                                            {...course}
                                                            onClick={() => handleClassClick(course.id)}
                                                            className={styles.courseItem}
                                                        >
                                                            <ImportContactsRoundedIcon
                                                                style={{color: colors[course.id % colors.length]}}/>
                                                            <div className={styles.courseCardTitle}>
                                                                <p>{course.name}</p>

                                                            <div className={styles.labelContainer}>
                                                                <div className={styles.label1}>Beginner </div>
                                                                <div>7-12</div>
                                                            </div>
                                                            </div>
                                                        </MenuItem>
                                                    ))) : <Typography variant="h6" align="center" color="#fff">
                                                    No courses available
                                                </Typography>}
                                            </div>
                                        </Menu>)}
                                </div>
                            ))}
                        </div>

                        {user.isLoggedIn ? (
                            <div className={styles.login}>
                                <Button variant="text" onClick={() => handleNavigation(routeMap.courseSelection)}>
                                    Course Selection
                                </Button>
                                <Button variant="text" onClick={() => handleNavigation(routeMap.account)}>
                                    Account
                                </Button>
                                <Button variant="text" onClick={handleLogoutClick}>
                                    Logout
                                </Button>
                            </div>
                        ) : (
                            <div className={styles.login}>
                                <Button variant="text" onClick={() => handleNavigation(routeMap.login)} disableRipple>
                                    Login
                                </Button>
                                <Button variant="text" onClick={() => handleNavigation(routeMap.register)}
                                        disableRipple>
                                    Register
                                </Button>
                            </div>
                        )}
                    </Toolbar>
                </div>
                <div className={styles.media}>
                    <Typography component="p">Youth AI Learning Platform</Typography>
                </div>
            </div>
        </div>
    );
}

export default Header;
