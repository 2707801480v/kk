import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField, FormControl, FormHelperText } from '@mui/material';
import emailjs from '@emailjs/browser';

const AppointmentPopupForm = ({ open, handleClose }) => {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [emailError, setEmailError] = useState(false);

    const handleSubmit = () => {
        if (email.trim() === '') {
            setEmailError(true);
            return;
        }

        const templateParams = {
            from_email: email,
            message: message
        };

        emailjs.send('service_l6obg1k', 'template_dbs81q8', templateParams, {
            publicKey: 'QiMciYTacHgr0vgIp',
        })
            .then((response) => {
                console.log('Email sent successfully!', response.status, response.text);
                handleClose();
            }, (error) => {
                console.error('Error sending email:', error);
            });
    };

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
        if (e.target.value.trim() !== '') {
            setEmailError(false);
        }
    };

    const handleClickInside = (event) => {
        event.stopPropagation();
    };

    return (
        <Dialog open={open} onClose={handleClose} onClick={handleClickInside}>
            <DialogTitle sx={{ textAlign: 'center' }}>Contact us</DialogTitle>
            <DialogContent>
                <FormControl fullWidth error={emailError}>
                    <TextField
                        required
                        autoFocus
                        margin="dense"
                        id="email"
                        label="Email Address"
                        type="email"
                        fullWidth
                        variant="standard"
                        value={email}
                        onChange={handleEmailChange}
                    />
                    {emailError && (
                        <FormHelperText>Email is required</FormHelperText>
                    )}
                </FormControl>
                <TextField
                    margin="dense"
                    id="message"
                    label="Message"
                    type="text"
                    fullWidth
                    variant="standard"
                    multiline
                    rows={10}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                />
            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose}>Cancel</Button>
                <Button onClick={handleSubmit}>Submit</Button>
            </DialogActions>
        </Dialog>
    );
};

export default AppointmentPopupForm;