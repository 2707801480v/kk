import React, { useState } from 'react';
import styles from './ModelSelection.module.css';
import { Autocomplete, TextField } from "@mui/material";

const modelOptions = [
    { title: 'Model 1' },
    { title: 'Model 2' },
    { title: 'Model 3' },
    { title: 'Model 4' }
];
function ModelSelectionCard() {
    const [selectedModel, setSelectedModel] = useState(null);

    return (
        <div className={styles.container}>
            <Autocomplete

                value={selectedModel}
                onChange={(event, newValue) => {
                    setSelectedModel(newValue);
                }}
                options={modelOptions}
                getOptionLabel={(option) => option.title}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        label="Select Model"
                        variant="outlined"
                        fullWidth
                    />
                )}
                sx={{ width: 350 }}
            />
        </div>
    );
}

export default ModelSelectionCard;