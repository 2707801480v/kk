import { Card, Typography } from '@mui/material';
import * as React from 'react';
import styles from './ChatgptCard.module.css';

const defaultQuestions = [
    { image: '', text: 'What is Youth AI?' },
    { image: '', text: 'How to use Youth AI?' },
    { image: '', text: 'Benefits of Youth AI?' },
    { image: '', text: 'Explain AI ethics.' }
];

function ChatgptCard({ onSelectQuestion }) {
    return (
        <React.Fragment>
            <div className={styles.cardContainer}>
                {defaultQuestions.map((item, index) => (
                    <Card key={index} className={styles.card} onClick={() => onSelectQuestion(item.text)}>
                        <div className={styles.cardContent}>
                            <img className={styles.img} src={item.image} alt={item.image} />
                            <Typography className={styles.textContent} gutterBottom variant="body1" component="div">
                                {item.text}
                            </Typography>
                        </div>
                    </Card>
                ))}
            </div>
        </React.Fragment>
    );
}

export default ChatgptCard;