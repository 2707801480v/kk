import * as React from 'react';
import Typography from "@mui/material/Typography";
import ImportContactsRoundedIcon from '@mui/icons-material/ImportContactsRounded';
import { Button } from "@mui/material";
import styles from './CourseCard.module.css';

function CourseCard({ id, name, description, imageUrl, onCardClick, onAppointmentClick }) {
    const colors = ['#26a398', '#8ac94e', '#fa0', '#eb0001', '#238538', '#183f74'];

    const iconColor = colors[id % colors.length];
    const buttonColor = colors[(id + 1) % colors.length];

    const handleCardClick = (event) => {
        if (event.target.tagName.toLowerCase() !== 'button') {
            onCardClick(id, event);
        }
    };

    return (
        <div
            className={styles.courseCard}
            onClick={handleCardClick}
        >
            <div className={styles.courseCardImage}>
                {imageUrl ? (
                    <img src={imageUrl} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                    <Typography variant="body2">Course Image</Typography>
                )}
            </div>
            <div className={styles.courseCardContent}>
                <div className={styles.courseTitle}>
                    <ImportContactsRoundedIcon style={{ color: iconColor }} />
                    <p className={styles.courseCardTitle}>
                        {name}
                    </p>
                </div>
                <div className={styles.labelContainer}>
                    <div className={styles.label1}>3 Days</div>
                    <div className={styles.label2}>Ages 7-12</div>
                </div>
                <p className={styles.courseSubTitle}>
                    For the future innovators!
                </p>
                <Typography className={styles.courseCardDescription}>
                    {description}
                </Typography>
            </div>
            <div className={styles.courseCardFooter}>
                <Button
                    variant="contained"
                    fullWidth
                    onClick={(event) => {
                        event.stopPropagation();
                        onAppointmentClick(event);
                    }}
                    className={styles.button}
                    style={{ backgroundColor: buttonColor }}
                >
                    Make an Appointment
                </Button>
            </div>
        </div>
    );
}

export default CourseCard;