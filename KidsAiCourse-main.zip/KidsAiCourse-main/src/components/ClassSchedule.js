import React, { useState, useEffect, useCallback } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Typography, Tooltip, Box } from '@mui/material';
import {
    parse,
    format,
    addDays,
} from 'date-fns';

function ClassSchedule({ flag, startDate, endDate, courseId, setClasses, chosenClasses, setChosenClasses, onCellClick, tooltipMessage, alwaysShowTooltip }) {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const userId = sessionStorage.getItem("userId");
    const [localClasses, setLocalClasses] = useState([]);
    const timeRanges = [];
    for (let hour = 9; hour < 17; hour++) {
        for (let minute = 0; minute < 60; minute += 30) {
            const startTime = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
            const endHour = minute === 30 ? hour + 1 : hour;
            const endMinute = minute === 30 ? '00' : '30';
            const endTime = `${endHour.toString().padStart(2, '0')}:${endMinute}`;
            timeRanges.push(`${startTime}-${endTime}`);
        }
    }

    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

    const getDates = () => {
        const dates = [];
        let currentDate = parse(startDate, 'dd/MM/yyyy', new Date());
        for (let i = 0; i < 5; i++) {
            dates.push(addDays(currentDate, i));
        }
        return dates;
    };

    const dates = getDates();

    const formatDate = (date) => {
        return format(date, 'dd/MM/yyyy');
    };

    const getClassListByCourseId = useCallback(async () => {
        if (!courseId) return;
        try {
            const response = await fetch(`${baseUrl}/kidsai/class/findByCourseId?courseId=${courseId}&startDate=${encodeURIComponent(startDate)}&endDate=${encodeURIComponent(endDate)}&userId=${encodeURIComponent(userId)}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            });
            if (response.status === 200) {
                const data = await response.json();
                setLocalClasses(data.result);
                setClasses(data.result);
                const newChosenClasses = data.result
                    .filter(c => !c.isDeleted)
                    .map(c => c.classId);
                setChosenClasses(newChosenClasses);
                console.log("setChosenClasses:", newChosenClasses);
            }
        } catch (error) {
            console.error("Error get class list by course id: ", error);
        }
    }, [baseUrl, courseId, startDate, endDate, setClasses, userId, setChosenClasses]);

    const getClassListByUserId = useCallback(async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/userClass/getUserClasses?userId=${userId}&startDate=${startDate}&endDate=${endDate}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            });
            if (response.status === 200) {
                const data = await response.json();
                setLocalClasses(data.result);
                setClasses(data.result);
                const newChosenClasses = data.result
                    .map(c => c.id);
                setChosenClasses(newChosenClasses);
                console.log("setChosenClasses:", newChosenClasses);
            }
        } catch (error) {
            console.error("Error get class list by user id: ", error);
        }
    }, [baseUrl, startDate, endDate, setClasses, userId, setChosenClasses]);

    useEffect(() => {
        if (flag === 0) {
            getClassListByCourseId();
        } else {
            getClassListByUserId();
        }
    }, [flag, getClassListByCourseId, getClassListByUserId]);

    const renderClassCells = () => {
        const cells = {};
        days.forEach(day => {
            cells[day] = timeRanges.map(() => null);
        });

        if (Array.isArray(localClasses) && localClasses.length > 0) {
            localClasses.forEach(cls => {
                const dayIndex = days.findIndex(day => day.toUpperCase() === cls.dayOfWeek.toUpperCase());
                if (dayIndex !== -1) {
                    const startIndex = timeRanges.findIndex(range => range.startsWith(cls.startTime));
                    const endIndex = timeRanges.findIndex(range => range.endsWith(cls.endTime));
                    if (startIndex !== -1 && endIndex !== -1) {
                        const isChosen = chosenClasses.includes(cls.classId || cls.id);
                        const showTooltip = alwaysShowTooltip || !isChosen;
                        const rowSpan = endIndex - startIndex + 1;
                        cells[days[dayIndex]][startIndex] = (
                            <TableCell
                                key={`${cls.dayOfWeek}-${cls.startTime}`}
                                align="center"
                                sx={{
                                    padding: 1,
                                    verticalAlign: 'top',
                                    height: `${rowSpan * 50}px`,
                                }}
                                rowSpan={rowSpan}
                            >
                                <Box
                                    sx={{
                                        backgroundColor: isChosen ? '#e3f2fd' : 'inherit',
                                        border: isChosen ? '1px solid #1976d2' : '1px solid rgba(224, 224, 224, 1)',
                                        borderRadius: '8px',
                                        cursor: 'pointer',
                                        padding: '4px',
                                        height: '100%',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                    }}
                                    onClick={() => onCellClick(cls, isChosen)}
                                >
                                    <Tooltip title={showTooltip ? tooltipMessage : ''} placement="top">
                                        <div>
                                            <Typography variant="body2">{cls.name}</Typography>
                                            <Typography variant="caption">{cls.location}</Typography>
                                            <Typography variant="caption" display="block">{`${cls.startTime} - ${cls.endTime}`}</Typography>
                                        </div>
                                    </Tooltip>
                                </Box>
                            </TableCell>
                        );
                        for (let i = startIndex + 1; i <= endIndex; i++) {
                            cells[days[dayIndex]][i] = 'occupied';
                        }
                    }
                }
            });
        }

        return cells;
    };

    const classCells = renderClassCells();

    return (
        <TableContainer component={Paper} sx={{ borderRadius: '12px', overflow: 'hidden' }}>
            <Table sx={{ minWidth: 650 }} aria-label="class schedule table">
                <TableHead>
                    <TableRow>
                        <TableCell></TableCell>
                        {days.map((day, index) => (
                            <TableCell key={day} align="center">
                                <Typography variant="subtitle1">{day}</Typography>
                                <Typography variant="caption">
                                    {formatDate(dates[index])}
                                </Typography>
                            </TableCell>
                        ))}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {timeRanges.map((timeRange, timeIndex) => (
                        <TableRow key={timeRange} sx={{ height: '50px' }}>
                            <TableCell component="th" scope="row">
                                {timeRange}
                            </TableCell>
                            {days.map(day => {
                                const cell = classCells[day][timeIndex];
                                if (cell === 'occupied') {
                                    return null;
                                }
                                return cell || <TableCell key={`${day}-${timeRange}`} />;
                            })}
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}

export default ClassSchedule;