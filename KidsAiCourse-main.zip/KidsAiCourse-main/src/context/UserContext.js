import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

const UserContext = createContext();

const UserProvider = ({ children }) => {
    const [user, setUser] = useState({ isLoggedIn: false });
    const baseUrl = process.env.REACT_APP_BASE_URL;

    const fetchUserStatus = async () => {
        try {
            const response = await axios.get(`${baseUrl}/kidsai/user/status`, {
                headers: {
                    'Content-Type': 'application/json'
                },
                withCredentials: true
            });

            setUser({ isLoggedIn: response.data.result });
        } catch (error) {
            console.error('Failed to fetch user status:', error);
            setUser({ isLoggedIn: false });
        }
    };

    useEffect(() => {
        fetchUserStatus();
    }, []);

    return (
        <UserContext.Provider value={{ user, setUser, fetchUserStatus }}>
            {children}
        </UserContext.Provider>
    );
};

export { UserContext, UserProvider };
