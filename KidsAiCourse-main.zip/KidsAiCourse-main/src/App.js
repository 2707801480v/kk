import './App.css';
import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Header from "./components/Header";
import HomePage from "./pages/HomePage";
import { routeMap } from "./routeMap";
import CourseResources from "./pages/CourseResources";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import PersonalInformation from "./pages/PersonalInformation";
import ContactUsPage from "./pages/ContactUsPage";
import TextGeneratedImages from './pages/TextGeneratedImages';
import ImageGeneratedImage from './pages/ImageGeneratedImage';
import CoursDetails from './pages/CourseDetails';
import FunctionUsagePage from "./pages/FunctionUsagePage";
import CourseSelectionPage from './pages/CourseSelectionPage';
import { UserProvider } from './context/UserContext';
import AccountPage from './pages/AccountPage';
import ChatgptPage from "./pages/ChatgptPage";

const routesIndex = [
    { path: routeMap.homepage, component: <HomePage /> },
    { path: routeMap.courseResources, component: <CourseResources /> },
    { path: routeMap.login, component: <LoginPage /> },
    { path: routeMap.register, component: <RegisterPage /> },
    { path: routeMap.personalInfo, component: <PersonalInformation /> },
    { path: routeMap.contactUs, component: <ContactUsPage /> },
    { path: routeMap.textGeneratedImages, component: <TextGeneratedImages /> },
    { path: routeMap.imageGeneratedImage, component: <ImageGeneratedImage /> },
    { path: `${routeMap.courseDetails}/:courseId`, component: <CoursDetails /> },
    { path: routeMap.functionUsage, component: <FunctionUsagePage /> },
    { path: routeMap.courseSelection, component: <CourseSelectionPage /> },
    { path: routeMap.account, component: <AccountPage /> },
    {path: routeMap.chatgpt, component: <ChatgptPage />}

];

const theme = createTheme({
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    '&:hover': {
                        backgroundColor: 'inherit',
                        color: 'inherit',
                    },
                    '&:focus': {
                        backgroundColor: 'inherit',
                        color: 'inherit',
                    },
                    '&:active': {
                        backgroundColor: 'inherit',
                        color: 'inherit',
                    },
                },
            },
        },
    },
});

function App() {
    return (
        <React.Fragment>
            <ThemeProvider theme={theme}>
                <CssBaseline />
                <UserProvider>
                    <BrowserRouter>
                        <div className="App">
                            <Header />
                            <div style={{ backgroundColor: "rgb(245, 245, 245)", padding: "8px" }}>
                                <div style={{borderRadius: "10px", backgroundColor: "#fff", padding: "16px" }}>
                                    <Routes>
                                        {routesIndex.map(({ path, component }, key) => (
                                            <Route path={path} element={component} key={key} />
                                        ))}
                                    </Routes>
                                </div>
                            </div>
                        </div>
                    </BrowserRouter>
                </UserProvider>
            </ ThemeProvider>
        </React.Fragment>
    );
}

export default App;