const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
    app.use(
        '/kidsai',
        createProxyMiddleware({
            target: process.env.REACT_APP_BASE_URL,
            changeOrigin: true,
            pathRewrite: {
                '^/kidsai': '/',
            },
        })
    );
};