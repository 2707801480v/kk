import React, { useState, useEffect, useCallback } from 'react';
import { Card, Autocomplete, TextField, Typography, Button } from "@mui/material";
import CourseCard from "../components/CourseCard";
import { useNavigate } from "react-router-dom";
import styles from './CourseResources.module.css'

function CourseResources() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const [courseTypeList, setCourseTypeList] = useState([]);
    const [selectedCourseType, setSelectedCourseType] = useState(null);
    const [courseList, setCourseList] = useState([]);

    const navigate = useNavigate();
    const handleCardClick = (courseId, event) => {
        navigate(`/course-details/${courseId}`);
    };

    const handleAppointmentClick = (event) => {
        navigate(`/course-selection`);
    }

    const fetchData = useCallback(async (url, options = {}) => {
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                ...options
            });
            if (response.status === 200) {
                return await response.json();
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        } catch (error) {
            console.error(`Error fetching data from ${url}:`, error);
            return null;
        }
    }, []);

    useEffect(() => {
        const getCourseTypeList = async () => {
            const data = await fetchData(`${baseUrl}/kidsai/courseType/getList`);
            if (data) setCourseTypeList(data.result);
        };
        getCourseTypeList();
    }, [baseUrl, fetchData]);

    useEffect(() => {
        const getCourseList = async () => {
            let url = `${baseUrl}/kidsai/course/findAll`;
            if (selectedCourseType) {
                url = `${baseUrl}/kidsai/course/findCoursesByType?courseTypeId=${encodeURIComponent(selectedCourseType.id)}`;
            }
            const data = await fetchData(url);
            if (data) setCourseList(data.result);
        };
        getCourseList();
    }, [baseUrl, selectedCourseType, fetchData]);

    return (
        <div className={styles.container}>
            <Card>
                <div className={styles.dropDownBox}>
                    <Autocomplete
                        value={selectedCourseType}
                        onChange={(event, newValue) => setSelectedCourseType(newValue)}
                        options={courseTypeList}
                        getOptionLabel={(option) => option.name}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Select Course Type"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                        sx={{ width: 350 }}
                    />
                </div>
            </Card>
            {courseList.length > 0 ? (
                <div className={styles.courseGrid}>
                    {courseList.map((course, index) => (
                        <CourseCard
                            key={course.id || index}
                            {...course}
                            onCardClick={handleCardClick}
                            onAppointmentClick={handleAppointmentClick}
                        />
                    ))}
                </div>
            ) : (
                <Typography variant="h6" align="center">
                    No courses available
                </Typography>
            )}
        </div>
    );
}
export default CourseResources;
