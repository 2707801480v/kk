import * as React from 'react';
import { useEffect, useState } from 'react';
import styles from './PersonalInformation.module.css';
import {
    Button,
    Card,
    Typography,
    Checkbox,
    FormLabel,
    Tabs,
    Tab,
    Grid
} from "@mui/material";

const baseUrl = process.env.REACT_APP_BASE_URL;
function PersonalInformation() {
    const [userData, setUserData] = useState({});

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const response = await fetch(`${baseUrl}/kidsai/user`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                });
                if (response.ok) {
                    const data = await response.json();
                    if (data.code === '200') {
                        setUserData(data.result);
                    }
                } else {
                    console.error('Failed to fetch user data');
                }
            } catch (error) {
                console.error('Error fetching user data:', error);
            }
        };

        fetchUserData();
    }, []);

    return (
        <div className={styles.root}>
            <Card className={styles.register}>
                <Grid container spacing={2}>
                    <Grid item xs={4} md={4} className={styles.item}>
                        <FormLabel>User Name:</FormLabel>
                        <Typography variant="body1" component="p">
                            {userData?.username}
                        </Typography>
                    </Grid>
                    <Grid item xs={6} md={6} className={styles.item}>
                        <FormLabel>Email:</FormLabel>
                        <Typography variant="body1" component="p">
                            {userData?.email}
                        </Typography>
                    </Grid>
                    <Grid item xs={4} md={4} className={styles.item}>
                        <FormLabel>Role:</FormLabel>
                        <Typography variant="body1" component="p">
                            { userData?.role}
                        </Typography>
                    </Grid>
                    <Grid item xs={4} md={4} className={styles.item}>
                        <FormLabel>Mobile Number:</FormLabel>
                        <Typography variant="body1" component="p">
                            {userData?.mobile}
                        </Typography>
                    </Grid>
                </Grid>
                <div className={styles.registerBtn}>
                    <Button variant="outlined">Modify Information</Button>
                    <div className={styles.registerCheckbox}>
                        <Checkbox/><Typography variant="body1" component="p">You have read and agree to the "Youth AI Service Platform Service Terms"</Typography>
                    </div>
                </div>
            </Card>
        </div>
    );
}

export default PersonalInformation;