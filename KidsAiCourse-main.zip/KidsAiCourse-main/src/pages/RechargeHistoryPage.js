import React, { useState, useEffect } from 'react';
import {
    Box,
    Table,
    TableBody,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    TableCell
} from '@mui/material';
import { styled } from '@mui/material/styles';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    fontWeight: 'bold',
    textAlign: 'center',
}));

const RechargeButton = styled(Button)(({ theme }) => ({
    backgroundColor: theme.palette.warning.main,
    color: theme.palette.common.white,
    '&:hover': {
        backgroundColor: theme.palette.warning.dark,
    },
}));

function RechargeHistoryPage() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const [userInfo, setUserInfo] = useState(null);
    const userId = sessionStorage.getItem('userId');
    const [openRechargeDialog, setOpenRechargeDialog] = useState(false);
    const [rechargeAmount, setRechargeAmount] = useState('');
    const [rechargeError, setRechargeError] = useState('');
    const [rechargeHistory, setRechargeHistory] = useState([]);

    const fetchUserInfo = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/user`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            });
            if (response.status === 200) {
                const data = await response.json();
                setUserInfo(data.result);
            }
        } catch (error) {
            console.error("Error get user info:", error);
        }
    };
    const fetchRechargeHistory = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/rechargeHistory/getList?userId=${userId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            });
            if (response.status === 200) {
                const data = await response.json();
                setRechargeHistory(data.result);
            }
        } catch (error) {
            console.error("Error get user info:", error);
        }
    };

    useEffect(() => {
        fetchUserInfo();
        fetchRechargeHistory();
    }, []);

    const handleRechargeOpen = () => {
        setOpenRechargeDialog(true);
    };

    const handleRechargeClose = () => {
        setOpenRechargeDialog(false);
        setRechargeAmount('');
        setRechargeError('');
    };

    const handleRechargeAmountChange = (event) => {
        const value = event.target.value;
        if (/^\d*\.?\d{0,2}$/.test(value)) {
            setRechargeAmount(value);
            if (value && (parseFloat(value) < 1 || parseFloat(value) > 1000)) {
                setRechargeError('Please enter an amount between 1 and 1000');
            } else {
                setRechargeError('');
            }
        }
    };

    const handleRechargeSubmit = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/rechargeHistory/save?userId=${encodeURIComponent(userId)}&rechargeAmount=${rechargeAmount}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include'
            });
            if (response.status === 200) {
                alert("User recharge successfully.");
                await fetchUserInfo();
                await fetchRechargeHistory();
                setRechargeAmount('');
                setRechargeError('');
            }
        } catch (error) {
            console.error('Error user recharge:', error);
        } finally {
            handleRechargeClose();
        }
    };

    return (
        <Box>
            {userInfo && (
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
                    <TableContainer component={Paper}>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <StyledTableCell>UserName</StyledTableCell>
                                    <StyledTableCell>Balance</StyledTableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow>
                                    <StyledTableCell>{userInfo.username}</StyledTableCell>
                                    <StyledTableCell>{userInfo.balance}</StyledTableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <RechargeButton variant="outlined" onClick={handleRechargeOpen}>Recharge</RechargeButton>
                </Box>
            )}

            {rechargeHistory && (
                <TableContainer component={Paper} sx={{ mt: 4 }}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <StyledTableCell>Recharge Amount</StyledTableCell>
                                <StyledTableCell>Recharge Date</StyledTableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rechargeHistory.map((history, index) => (
                                <TableRow key={index}>
                                    <TableCell align="center">{history.rechargeAmount}</TableCell>
                                    <TableCell align="center">{history.rechargeDate}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            )}

            <Dialog open={openRechargeDialog} onClose={handleRechargeClose}>
                <DialogTitle>Recharge</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Recharge Amount"
                        type="text"
                        fullWidth
                        value={rechargeAmount}
                        onChange={handleRechargeAmountChange}
                        error={!!rechargeError}
                        helperText={rechargeError || 'Enter an amount between 1 and 1000'}
                        inputProps={{
                            inputMode: 'decimal',
                            pattern: '[0-9]*\\.?[0-9]{0,2}',
                        }}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleRechargeClose}>Cancel</Button>
                    <Button
                        onClick={handleRechargeSubmit}
                        disabled={!!rechargeError || !rechargeAmount || parseFloat(rechargeAmount) < 1 || parseFloat(rechargeAmount) > 1000}
                    >
                        Confirm
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
}

export default RechargeHistoryPage;
