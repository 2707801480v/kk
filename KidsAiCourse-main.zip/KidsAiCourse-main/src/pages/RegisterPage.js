import React, { useState, useEffect } from 'react';
import styles from './RegisterPage.module.css';
import {
    Button,
    Typography,
    TextField,
    Checkbox,
    FormGroup,
    FormLabel,
    Snackbar,
    Grid,
    Radio,
    RadioGroup,
    FormControl,
    FormControlLabel
} from "@mui/material";
import MuiAlert from '@mui/material/Alert';
import { useNavigate } from "react-router-dom";

function RegisterPage() {
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [role, setRole] = useState(0);
    const [email, setEmail] = useState('');
    const [emailError, setEmailError] = useState('');
    const [verificationCode, setVerificationCode] = useState('');
    const [username, setUsername] = useState('');
    const [usernameError, setUsernameError] = useState('');
    const [password, setPassword] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [confirmPasswordError, setConfirmPasswordError] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [phoneNumberError, setPhoneNumberError] = useState('');
    const [uuid, setUuid] = useState('');
    const [registerError, setRegisterError] = useState('');
    const [isTermsChecked, setIsTermsChecked] = useState(false);
    const [isFormValid, setIsFormValid] = useState(false);
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const navigate = useNavigate();

    const handleChange = (event, newValue) => {
        setRole(newValue);
    };

    const validateEmail = (email) => {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email) return 'Email is required';
        if (email.length > 50) return 'Email must not exceed 50 characters';
        if (!emailPattern.test(email)) return 'Invalid email format';
        return '';
    };

    const validateUsername = (username) => {
        if (!username) return 'Username is required';
        if (username.length > 20) return 'Username must not exceed 20 characters';
        return '';
    };

    const validatePassword = (password) => {
        if (!password) return 'Password is required';
        if (password.length < 8 || password.length > 20) return 'Password must be 8 to 20 characters long';
        return '';
    };

    const validateConfirmPassword = (confirmPassword, password) => {
        if (!confirmPassword) return 'Confirm Password is required';
        if (confirmPassword !== password) return 'Passwords do not match';
        return '';
    };

    const validatePhoneNumber = (phoneNumber) => {
        const phonePattern = /^04\d{8}$/;
        if (phoneNumber && !phonePattern.test(phoneNumber)) return 'Invalid Australian mobile number format';
        return '';
    };

    const handleEmailBlur = async () => {
        const error = validateEmail(email);
        setEmailError(error);
        if (!error) {
            try {
                const response = await fetch(`${baseUrl}/kidsai/email/check?email=${encodeURIComponent(email)}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
                if (response.status !== 200) {
                    setEmailError('Email is already in use');
                } else {
                    setEmailError('');
                }
            } catch (error) {
                console.error('Error checking email:', error);
                setEmailError('Error validating email');
            }
        }
    };

    const handleUsernameBlur = () => {
        const error = validateUsername(username);
        setUsernameError(error);
    };

    const handlePasswordBlur = () => {
        const error = validatePassword(password);
        setPasswordError(error);
    };

    const handleConfirmPasswordBlur = () => {
        const error = validateConfirmPassword(confirmPassword, password);
        setConfirmPasswordError(error);
    };

    const handlePhoneNumberBlur = () => {
        const error = validatePhoneNumber(phoneNumber);
        setPhoneNumberError(error);
    };

    const handleVerificationCodeClick = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/email/send?email=${encodeURIComponent(email)}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (response.ok) {
                const data = await response.json();
                if (data.code === '200') {
                    setUuid(data.result);
                    console.log('Verification code received, uuid:', data.result);
                }
            }
        } catch (error) {
            console.error('Error fetching verification code:', error);
        }
    };

    const validateEmailCode = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/email/valid?code=${verificationCode}&uuid=${uuid}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (response.ok) {
                const data = await response.json();
                if (data.code === '200') {
                    return true;
                }
            }
            return false;
        } catch (error) {
            console.error('Error validating email code:', error);
            return false;
        }
    };

    const handleRegisterClick = async () => {
        const emailError = validateEmail(email);
        const usernameError = validateUsername(username);
        const passwordError = validatePassword(password);
        const confirmPasswordError = validateConfirmPassword(confirmPassword, password);
        const phoneNumberError = validatePhoneNumber(phoneNumber);

        setEmailError(emailError);
        setUsernameError(usernameError);
        setPasswordError(passwordError);
        setConfirmPasswordError(confirmPasswordError);
        setPhoneNumberError(phoneNumberError);

        if (emailError || usernameError || passwordError || confirmPasswordError || phoneNumberError) return;

        const isValid = await validateEmailCode();
        if (!isValid) {
            setRegisterError('Email verification failed');
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/kidsai/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    'email': email,
                    'username': username,
                    'password': password,
                    'mobile': phoneNumber,
                    'verificationCode': verificationCode,
                    'uuid': uuid,
                    'role': role
                })
            });
            if (response.ok) {
                const data = await response.json();
                if (data.code === '200') {
                    setSnackbarOpen(true);
                    setTimeout(() => {
                        navigate('/login');
                    }, 2000);
                } else {
                    setRegisterError(data.message || 'Registration failed');
                }
            } else {
                const errorData = await response.json();
                setRegisterError(errorData.message || 'Registration failed');
            }
        } catch (error) {
            console.error('Error registering:', error);
            setRegisterError('Registration failed');
        }
    };

    useEffect(() => {
        const isFormComplete = email !== '' &&
            username !== '' &&
            password !== '' &&
            confirmPassword !== '' &&
            verificationCode !== '' &&
            isTermsChecked &&
            !emailError &&
            !usernameError &&
            !passwordError &&
            !confirmPasswordError &&
            !phoneNumberError;

        setIsFormValid(isFormComplete);
    }, [email, username, password, confirmPassword, verificationCode, isTermsChecked, emailError, usernameError, passwordError, confirmPasswordError, phoneNumberError]);

    return (
        <div className={styles.root}>
            <div className={styles.register}>
                <FormGroup>
                    <Grid container spacing={2}>
                        <Grid item xs={12} md={12} className={styles.item}>
                            <FormLabel>Email</FormLabel>
                            <TextField
                                required
                                fullWidth
                                placeholder="Please enter your email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                onBlur={handleEmailBlur}
                                error={!!emailError}
                                helperText={emailError || ""}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} className={styles.item}>
                            <FormLabel>Verification Code:</FormLabel>
                            <div className={styles.verification}>
                                <TextField
                                    fullWidth
                                    placeholder="Please enter the verification code"
                                    value={verificationCode}
                                    onChange={(e) => setVerificationCode(e.target.value)}
                                />
                                <Button
                                    variant="contained"
                                    className={styles.verificationBtn}
                                    onClick={handleVerificationCodeClick}
                                >
                                    Send Code
                                </Button>
                            </div>
                        </Grid>
                        <Grid item xs={12} md={12} className={styles.item}>
                            <FormLabel>User Name</FormLabel>
                            <TextField
                                required
                                fullWidth
                                placeholder="Please enter your username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                onBlur={handleUsernameBlur}
                                error={!!usernameError}
                                helperText={usernameError || ""}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} className={styles.item}>
                            <FormLabel>Set Password</FormLabel>
                            <TextField
                                required
                                fullWidth
                                type="password"
                                placeholder="Please enter your password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                onBlur={handlePasswordBlur}
                                helperText={passwordError || "Prompt: The password contains 8 to 20 characters"}
                                error={!!passwordError}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} className={styles.item}>
                            <FormLabel>Confirm Password</FormLabel>
                            <TextField
                                required
                                fullWidth
                                type="password"
                                placeholder="Please enter your password again"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                onBlur={handleConfirmPasswordBlur}
                                helperText={confirmPasswordError || "Prompt: Please re-enter your password"}
                                error={!!confirmPasswordError}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} className={styles.item}>
                            <FormLabel>Mobile Number</FormLabel>
                            <TextField
                                fullWidth
                                placeholder="Please enter your phone number"
                                value={phoneNumber}
                                onChange={(e) => setPhoneNumber(e.target.value)}
                                onBlur={handlePhoneNumberBlur}
                                error={!!phoneNumberError}
                                helperText={phoneNumberError || ""}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} className={styles.role}>
                            <FormControl component="fieldset" fullWidth>
                                <RadioGroup row value={role} onChange={handleChange} className={styles.radio}>
                                    <FormControlLabel value={0} control={<Radio/>} label="Student"/>
                                    <FormControlLabel value={1} control={<Radio/>} label="Parents"/>
                                </RadioGroup>
                            </FormControl>
                        </Grid>
                    </Grid>
                </FormGroup>
                <div className={styles.registerBtn}>
                    <Button
                        variant="outlined"
                        onClick={handleRegisterClick}
                        disabled={!isFormValid}
                    >
                        Register Now
                    </Button>
                    {registerError && (
                        <Typography color="error" variant="body2">
                            {registerError}
                        </Typography>
                    )}
                    <div className={styles.registerCheckbox}>
                        <Checkbox
                            checked={isTermsChecked}
                            onChange={(e) => setIsTermsChecked(e.target.checked)}
                        />
                        <Typography variant="body1" component="p">
                            You have read and agree to the "Youth AI Service Platform Service Terms"
                        </Typography>
                    </div>
                </div>
            </div>
            <Snackbar
                open={snackbarOpen}
                autoHideDuration={2000}
                onClose={() => setSnackbarOpen(false)}
            >
                <MuiAlert elevation={6} variant="filled" severity="success">
                    Registration successful! Please login.
                </MuiAlert>
            </Snackbar>
        </div>
    );
}

export default RegisterPage;