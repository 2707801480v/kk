import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from "react-router-dom";
import styles from './HomePage.module.css';
import { Typography, Tabs, Tab } from '@mui/material';
import ChatgptPage from './ChatgptPage';
import CourseCard from '../components/CourseCard';
import FunctionUsagePage from "./FunctionUsagePage";

const HomePage = () => {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const [courseList, setCourseList] = useState([]);

    const navigate = useNavigate();
    const handleCardClick = (courseId, event) => {
        navigate(`/course-details/${courseId}`);
    };
    const handleAppointmentClick = (event) => {
        navigate(`/course-selection`);
    }

    const fetchData = useCallback(async (url, options = {}) => {
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                ...options
            });
            if (response.status === 200) {
                return await response.json();
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        } catch (error) {
            console.error(`Error fetching data from ${url}:`, error);
            return null;
        }
    }, []);

    useEffect(() => {
        const getCourseList = async () => {
            let url = `${baseUrl}/kidsai/course/findAll`;
            const data = await fetchData(url);
            if (data) setCourseList(data.result);
        };
        getCourseList();
    }, [baseUrl, fetchData]);

    return (
        <div className={styles.root}>

                <div className={styles.cardContainer}>
                    {courseList.length > 0 ? (
                        courseList.map((course, index) => (
                            <CourseCard
                                key={course.id || index}
                                {...course}
                                onCardClick={handleCardClick}
                                onAppointmentClick={handleAppointmentClick}
                            />
                        ))
                    ) : (
                        <Typography variant="h6" align="center">
                            No courses available
                        </Typography>
                    )}
                </div>
        </div>
    );
};

export default HomePage;