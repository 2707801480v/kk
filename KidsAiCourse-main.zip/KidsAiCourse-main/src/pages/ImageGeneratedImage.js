import { Card, Button, CircularProgress, TextareaAutosize } from '@mui/material';
import React, { useState, useEffect } from 'react';
import styles from './ImageGeneratedImage.module.css';
import AIText from '../components/AIText';
import ModelSelectionCard from '../components/ModelSelection';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import axios from 'axios';
import GeneratePageHistory from '../components/GeneratePageHistory.js';
import { modelsLabKey } from '../constants/general';

function ImageGeneratedImages() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const userId = sessionStorage.getItem('userId');
    const [generatedText] = useState('display generated image area...');
    const [inputValue, setInputValue] = useState('');
    const [uploadedImage, setUploadedImage] = useState(null);
    const [staticImageUrl, setStaticImageUrl] = useState('');
    const [futureLinkImage, setFutureLinkImage] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [history, setHistory] = useState(() => {
        const savedHistory = sessionStorage.getItem('imageGeneratedImageHistory');
        if (savedHistory) {
            return JSON.parse(savedHistory);
        } else {
            return [];
        }
    });

    const handleSubmit = () => {
        if (inputValue.trim() !== '') {
            setInputValue('');
        }
    };

    const handleInputChange = (event) => {
        setInputValue(event.target.value);
    };

    const handleKeyPress = (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            handleSubmit();
        }
    };

    const fetchImage = async () => {
        setFutureLinkImage('');
        setIsGenerating(true);
        setIsLoading(true);

        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            "key": modelsLabKey,
            "model_id": "lob-realvisxl-v20",
            "prompt": inputValue,
            "init_image": staticImageUrl,
            "negative_prompt": "painting, extra fingers, mutated hands, poorly drawn hands, poorly drawn face, deformed, blurry, bad anatomy, bad proportions, extra limbs, cloned face, glitchy, double torso, extra arms, extra hands, mangled fingers, missing lips,  distorted face, extra legs, anime, super heroes, costumes, phantasy",
            "width": "512",
            "height": "512",
            "samples": "1",
            "num_inference_steps": "30",
            "seed": null,
            "scheduler": 'UniPCMultistepScheduler',
            "guidance_scale": 7.5,
            "webhook": null,
            "track_id": null
        })

        const requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };
        console.log("requestOptions", requestOptions);

        async function fetchImageUrl() {
            try {
                const response = await fetch("https://modelslab.com/api/v6/images/img2img", requestOptions);
                const result = await response.text();
                console.log("init_image", staticImageUrl);
                console.log("result:", result);
                const responseResult = JSON.parse(result);
                const imageJson = responseResult.output;
                console.log("imageJson", imageJson);
                saveUserBehaviour();
                if (imageJson.length === 0) {
                    if (responseResult.status === 'processing') {
                        console.log("eta:", responseResult.eta);
                        if (responseResult.eta < 60) {
                            setTimeout(async () => {
                                try {
                                    const futureResponse = await fetch(responseResult.future_links[0]);
                                    console.log("futureResponse.url:", futureResponse.url);
                                    setFutureLinkImage(futureResponse.url);
                                    updateHistoryAndSession(futureResponse.url);
                                } catch (error) {
                                    console.log('Error fetching future image:', error);
                                }
                            }, responseResult.eta * 1000);
                        }
                    }
                } else {
                    const generatedImageUrl = Array.isArray(imageJson) ? imageJson[0] : imageJson;
                    setFutureLinkImage(generatedImageUrl);
                    console.log("generatedImageUrl", generatedImageUrl);
                    updateHistoryAndSession(generatedImageUrl);
                }
            } catch (error) {
                console.log('error', error);
            } finally {
                setIsLoading(false);
            }
        }

        function updateHistoryAndSession(imageJson) {
            const newHistoryItem = {
                id: Date.now(),
                uploadedImage: staticImageUrl,
                generatedImage: imageJson,
                prompt: inputValue,
            };
            setHistory(prevHistory => [newHistoryItem, ...prevHistory]);
            const reversedHistory = [newHistoryItem, ...history];
            sessionStorage.setItem('imageGeneratedImageHistory', JSON.stringify(reversedHistory));
        }
        await fetchImageUrl();
        setIsGenerating(false);
    };

    const handleImageUpload = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const fileType = file.type;
        if (fileType !== 'image/png' && fileType !== 'image/jpeg') {
            alert('Only .png and .jpeg files are allowed');
            return;
        }

        const formData = new FormData();
        formData.append('image', file);

        const headers = {
            'Content-Type': 'multipart/form-data',
        };

        try {
            const response = await axios.post(
                'http://43.133.138.207:60/upload', formData, { headers }
            );
            console.log("upload file: fileUrl", response.data.url);
            setStaticImageUrl(response.data.url);
            setUploadedImage(response.data.url);
        } catch (error) {
            console.error('Error uploading file', error);
        } finally {
            setIsGenerating(false);
        }
    }

    const handleSelectHistoryItem = (item) => {
        if (item.uploadedImage) {
            setStaticImageUrl(item.uploadedImage);
            setUploadedImage(item.uploadedImage);
        }
        setFutureLinkImage(item.generatedImage);
        setInputValue(item.prompt);
    };

    const saveUserBehaviour = async () => {
        const saveRequestBody = {
            api: "api/v6/images/img2img",
            endpoint: "modelslab.com",
            userId: userId,
            prompt: inputValue.length > 120 ? inputValue.substring(0, 120) : inputValue
        };
        console.log("saveRequestBody: ", saveRequestBody);
        try {
            const response = await fetch(`${baseUrl}/kidsai/callAI/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(saveRequestBody),
                credentials: 'include'
            });
            console.log("Save API response:", response);
            if (response.status === 200) {
                console.log("Save user behaviour is successful, record: ", JSON.stringify(saveRequestBody));
            }
        } catch (saveError) {
            console.error('Error calling save API:', saveError);
        }
    }

    useEffect(() => {
        setIsGenerating(!uploadedImage);
    }, [uploadedImage]);

    return (
        <div className={styles.container}>
            <React.Fragment>
                <Card>
                    <ModelSelectionCard />
                    <GeneratePageHistory searchHistory={history} onSelectHistoryItem={handleSelectHistoryItem} />
                </Card>
            </React.Fragment>
            <Card>
                <AIText />
                <div className={styles.generateArea}>
                    <div className={styles.uploadArea}>
                        <label htmlFor="uploadInput" className={styles.uploadLabel}>
                            <div className={styles.uploadContent}>
                                {uploadedImage ? (
                                    <img src={uploadedImage} alt="Uploaded" className={styles.uploadedImage} />
                                ) : (
                                    <>
                                        <CloudUploadIcon className={styles.uploadIcon} />
                                        <span className={styles.uploadText}>Upload Image</span>
                                    </>
                                )}
                            </div>
                            <input id="uploadInput" type="file" accept="image/*" className={styles.uploadInput} onChange={handleImageUpload} />
                        </label>
                    </div>
                    <div className={styles.generateButton}>
                        <Button variant="contained" onClick={fetchImage} disabled={isGenerating || !uploadedImage || inputValue.trim() === ''}>
                            {isLoading ? <CircularProgress size={24} /> : 'Generate'}
                        </Button>
                    </div>
                    <div className={styles.generatedDisplayArea}>
                        {futureLinkImage && futureLinkImage !== '' ? (
                            <img
                                src={futureLinkImage}
                                alt="generated"
                                className={styles.generatedImage}
                            />
                        ) : (
                            <p>{generatedText}</p>
                        )}
                    </div>
                </div>
                <div className={styles.textBoxWrapper}>
                    {/* <TextBox inputValue={inputValue} setInputValue={setInputValue} handleSubmit={handleSubmit} /> */}
                    <TextareaAutosize className={styles.textArea} value={inputValue} onChange={handleInputChange} onKeyPress={handleKeyPress} placeholder="please enter the generate text" minRows={1} maxRows={4}></TextareaAutosize>
                </div>
            </Card>
        </div>
    );
}

export default ImageGeneratedImages;