import React from 'react';
import { Typography, Card } from "@mui/material";
import { useNavigate } from "react-router-dom";
import styles from './FunctionUsagePage.module.css';

function FunctionUsagePage() {
    const navigate = useNavigate();

    const handleCardClick = (title) => {
        if (title === 'Text generated images') {
            navigate('/text-generated-images');
        } else {
            navigate('/image-generated-image');
        }
    };

    const functions = [
        {
            title: "Image generation image",
            description: "Generate images based on other images",
        },
        {
            title: "Text generated images",
            description: "Generate images based on text descriptions",
        }
    ];

    return (
        <div className={styles.cardContainer}>
            {functions.map((func) => (
                <Card
                    key={func.title}
                    className={styles.functionCard}
                    onClick={() => handleCardClick(func.title)}
                >
                    <div className={styles.functionCardImage}>
                        <Typography variant="body2">Function Image</Typography>
                    </div>
                    <div className={styles.functionCardContent}>
                        <Typography className={styles.functionCardTitle}>
                            {func.title}
                        </Typography>
                        <Typography className={styles.functionCardDescription}>
                            {func.description}
                        </Typography>
                    </div>
                </Card>
            ))}
        </div>
    );
}

export default FunctionUsagePage;