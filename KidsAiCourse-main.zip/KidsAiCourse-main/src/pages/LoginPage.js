import * as React from 'react';
import { useState, useEffect } from 'react';
import styles from './LoginPage.module.css';
import { Button, Card, Typography, TextField, Radio, FormGroup, FormControlLabel } from "@mui/material";
import { routeMap } from "../routeMap";
import { useNavigate } from "react-router-dom";

function Login() {
    const [email, setEmail] = useState('');
    const [emailError, setEmailError] = useState(false);
    const [verificationCode, setVerificationCode] = useState('');
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const [uuid, setUuid] = useState('');
    const [pwd, setPwd] = useState('');
    const [loginError, setLoginError] = useState('');
    const [expiredError, setExpiredError] = useState('');
    const navigate = useNavigate();
    const [isVerificationButtonDisabled, setIsVerificationButtonDisabled] = useState(false);
    const [cooldownTime, setCooldownTime] = useState(0);
    const [verificationMessage, setVerificationMessage] = useState('');

    const handleEmailBlur = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/email/check?email=${encodeURIComponent(email)}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            console.log("email check response: ", response);
            if (response.status !== 200) {
                setEmailError(true);
            } else {
                setEmailError(false);
            }
        } catch (error) {
            console.error('Error checking email:', error);
            setEmailError(true);
        }
    };

    const handleVerificationCodeClick = async () => {
        setVerificationCode('');
        setExpiredError('');
        setIsVerificationButtonDisabled(true);
        setCooldownTime(60);
        setVerificationMessage('Please check your email for the verification code.');

        try {
            const response = await fetch(`${baseUrl}/kidsai/email/send?email=${encodeURIComponent(email)}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (response.ok) {
                const data = await response.json();
                console.log("email send response data:", data);
                if (data.code === '200') {
                    setUuid(data.result);
                    console.log('Verification code received, uuid:', data.result);
                }
            }
        } catch (error) {
            console.error('Error fetching verification code:', error);
        }
    };

    const handleLoginClick = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/email/valid?code=${verificationCode}&uuid=${uuid}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (response.ok) {
                const data = await response.json();
                console.log("email valid response data:", data);
                if (data.code === '200') {
                    console.log("Call email valid API is success.")
                    setExpiredError('');
                    // login API
                    handleLoginAPI();
                } else {
                    console.log("Call email valid API is fail.")
                }
            } else if (response.status === 400) {
                setExpiredError('Verification code has expired');
            }
        } catch (error) {
            console.error('Error fetching email valid :', error);
        }
    }

    const handleRegisterClick = () => navigate(routeMap.register)

    const handleLoginAPI = async () => {
        try {
            const response = await fetch(`${baseUrl}/kidsai/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    'email': email,
                    'password': pwd
                }),
                credentials: 'include',
            });
            if (response.ok) {
                const data = await response.json();
                if (data.code === '200') {
                    sessionStorage.setItem('userId', data.result.id);
                    window.location.href = routeMap.homepage;
                }
            } else if (response.status === 401) {
                setLoginError('Incorrect verification code or password');
                console.log("Call login API is fail.")
            }
        } catch (error) {
            console.error('Error fetching login :', error);
        }
    }

    useEffect(() => {
        let timer;
        if (cooldownTime > 0) {
            timer = setTimeout(() => {
                setCooldownTime(cooldownTime - 1);
            }, 1000);
        } else if (cooldownTime === 0 && isVerificationButtonDisabled) {
            setIsVerificationButtonDisabled(false);
            setVerificationMessage('');
        }
        return () => clearTimeout(timer);
    }, [cooldownTime, isVerificationButtonDisabled]);

    return (
        <div className={styles.root}>
            <Card className={styles.experience}>
                <Typography gutterBottom variant="h5" component="h2">Synchronize teaching resources</Typography>
                <Typography variant="body2" color="textSecondary" component="p">High quality basic education Synchronous resources, intelligent push</Typography>
                <Button variant="outlined">Experience now</Button>
            </Card>

            <Card className={styles.login}>
                <FormGroup className={styles.loginForm}>
                    <Typography gutterBottom variant="h5" component="h2">Login</Typography>
                    <TextField
                        required
                        fullWidth
                        placeholder="Please enter your account"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        onBlur={handleEmailBlur}
                        error={emailError}
                        helperText={emailError ? "Invalid email format" : ""}
                    />
                    <TextField required fullWidth type="password" onChange={(e) => {
                        setPwd(e.target.value);
                        setLoginError('');
                    }} placeholder="Please enter your password" />
                    <div className={styles.verification}>
                        <TextField required fullWidth placeholder="Please enter the verification code" error={expiredError !== ''}
                            helperText={expiredError} onChange={(e) => {
                                setVerificationCode(e.target.value);
                                setLoginError('');
                                setExpiredError('');
                            }} />
                        <Button
                            variant="contained"
                            className={styles.verificationBtn}
                            onClick={handleVerificationCodeClick}
                            disabled={isVerificationButtonDisabled}
                        >
                            {isVerificationButtonDisabled ? `Resend (${cooldownTime}s)` : 'Verification Code'}
                        </Button>
                    </div>
                    {verificationMessage && (
                        <Typography color="primary" variant="body2">
                            {verificationMessage}
                        </Typography>
                    )}
                    <div className={styles.verification}>
                        <FormControlLabel control={<Radio />} label="Next automatic login" />
                        <Button variant="text" onClick={handleRegisterClick}>Register</Button>
                    </div>
                    <Button variant="outlined" className={styles.loginBtn} onClick={handleLoginClick}>Login</Button>
                    {loginError && loginError !== 'Verification code has expired' && (
                        <Typography color="error" variant="body2">
                            {loginError}
                        </Typography>
                    )}
                </FormGroup>
            </Card>
        </div>
    );
}

export default Login;