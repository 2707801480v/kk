import { Card, Button, TextField, CircularProgress } from '@mui/material';
import React, { useState } from 'react';
import styles from './TextGeneratedImages.module.css';
import AIText from '../components/AIText';
import ModelSelectionCard from '../components/ModelSelection';
import { modelsLabKey } from '../constants/general';
import GeneratePageHistory from '../components/GeneratePageHistory.js';

function TextGeneratedImages() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const userId = sessionStorage.getItem('userId');
    const [inputText, setInputText] = useState('');
    const [imgUrl, setImgUrl] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [history, setHistory] = useState(() => {
        const savedHistory = sessionStorage.getItem('textGeneratedImageHistory');
        if (savedHistory) {
            return JSON.parse(savedHistory);
        } else {
            return [];
        }
    });
    const handleInputChange = (event) => {
        setInputText(event.target.value);
    };

    const fetchImage = async () => {
        setImgUrl('');
        setIsLoading(true);
        setIsGenerating(true);

        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            "key": modelsLabKey,
            "model_id": "lob-realvisxl-v20",
            "prompt": inputText,
            "negative_prompt": "painting, extra fingers, mutated hands, poorly drawn hands, poorly drawn face, deformed, blurry, bad anatomy, bad proportions, extra limbs, cloned face, glitchy, double torso, extra arms, extra hands, mangled fingers, missing lips,  distorted face, extra legs, anime, super heroes, costumes, phantasy",
            "width": "512",
            "height": "512",
            "samples": "1",
            "num_inference_steps": "30",
            "seed": null,
            "guidance_scale": 7.5,
            "webhook": null,
            "track_id": null
        });

        const requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };
        console.log("requestOptions", requestOptions);

        async function fetchImageUrl() {
            try {
                const response = await fetch("https://modelslab.com/api/v6/images/text2img", requestOptions);
                const result = await response.text();
                console.log("textGeneratedImageResult:", result);
                const responseResult = JSON.parse(result);
                const imageUrl = responseResult.output;
                console.log("imageUrl:", imageUrl);
                saveUserBehaviour();
                if (!imageUrl || imageUrl.length === 0) {
                    if (responseResult.status === 'processing') {
                        console.log("eta:", responseResult.eta);
                        if (responseResult.eta < 60) {
                            setTimeout(async () => {
                                try {
                                    const futureResponse = await fetch(responseResult.future_links[0]);
                                    console.log("futureResponse.url:", futureResponse.url);
                                    setImgUrl(futureResponse.url);
                                    updateHistoryAndSession(futureResponse.url);
                                } catch (error) {
                                    console.log('Error fetching future image:', error);
                                }
                            }, responseResult.eta * 1000);
                        }
                    }
                } else {
                    const staticImageUrl = Array.isArray(imageUrl) ? imageUrl[0] : imageUrl;
                    setImgUrl(staticImageUrl);
                    console.log("imageUrl", staticImageUrl);
                    updateHistoryAndSession(staticImageUrl);
                }
            } catch (error) {
                console.log('error', error);
            } finally {
                setIsLoading(false);
            }
        }

        function updateHistoryAndSession(imgUrl) {
            const newHistoryItem = {
                id: Date.now(),
                generatedImage: imgUrl,
                prompt: inputText,
            };
            setHistory(prevHistory => [newHistoryItem, ...prevHistory]);
            const reversedHistory = [newHistoryItem, ...history];
            sessionStorage.setItem('textGeneratedImageHistory', JSON.stringify(reversedHistory));
        }
        await fetchImageUrl();
        setIsGenerating(false);
    };

    const handleSelectHistoryItem = (item) => {
        setImgUrl(item.generatedImage);
        setInputText(item.prompt);
    };

    const saveUserBehaviour = async () => {
        const saveRequestBody = {
            api: "api/v6/images/text2img",
            endpoint: "modelslab.com",
            userId: userId,
            prompt: inputText.length > 120 ? inputText.substring(0, 120) : inputText
        };
        console.log("saveRequestBody: ", saveRequestBody);
        try {
            const response = await fetch(`${baseUrl}/kidsai/callAI/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(saveRequestBody),
                credentials: 'include'
            });
            console.log("Save API response:", response);
            if (response.status === 200) {
                console.log("Save user behaviour is successful, record: ", JSON.stringify(saveRequestBody));
            }
        } catch (saveError) {
            console.error('Error calling save API:', saveError);
        }
    }

    return (
        <div className={styles.container}>
            <React.Fragment>
                <Card>
                    <ModelSelectionCard />
                    <GeneratePageHistory searchHistory={history} onSelectHistoryItem={handleSelectHistoryItem} />
                </Card>
            </React.Fragment>
            <Card>
                <AIText />
                <div className={styles.textArea}>
                    <TextField
                        label="Please enter text"
                        value={inputText}
                        onChange={handleInputChange}
                        multiline
                        rows={18}
                        className={styles.textField}
                        InputProps={{
                            className: styles.textFieldInput,
                        }}
                    />
                    <div className={styles.generateButton}>
                        <Button variant="contained" onClick={fetchImage} disabled={isGenerating || inputText.trim() === ''}>
                            {isLoading ? <CircularProgress size={24} /> : 'Generate'}
                        </Button>
                    </div>
                    {imgUrl ? (
                        <img src={imgUrl} className={styles.img} alt="Generated" />
                    ) : (
                        <div className={styles.img}>
                            <span className={styles.placeholderText}>Generating effect display</span>
                        </div>)}
                </div>
            </Card>
        </div>
    );
}
export default TextGeneratedImages;