import React, { useState, useEffect, useCallback } from 'react';
import styles from './CourseSelectionPage.module.css';
import { Autocomplete, TextField, Card, ListItem, ListItemText, List, InputAdornment, Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ClassSchedule from '../components/ClassSchedule';

function CourseSelectionPage() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const userId = sessionStorage.getItem('userId');

    const [courseTypeList, setCourseTypeList] = useState([]);
    const [selectedCourseType, setSelectedCourseType] = useState(null);
    const [courseList, setCourseList] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCourseId, setSelectedCourseId] = useState(null);
    const [classes, setClasses] = useState([]);
    const [chosenClasses, setChosenClasses] = useState([]);
    const [tempSelectedClass, setTempSelectedClass] = useState(null);
    const [open, setOpen] = useState(false);

    const getNextWeekDateRange = useCallback(() => {
        const now = new Date();
        const dayOfWeek = now.getDay();
        const daysUntilNextMonday = (dayOfWeek === 0) ? 1 : (8 - dayOfWeek);
        const daysUntilNextSunday = daysUntilNextMonday + 6;
        const nextMonday = new Date(now);
        nextMonday.setDate(now.getDate() + daysUntilNextMonday);
        const nextSunday = new Date(now);
        nextSunday.setDate(now.getDate() + daysUntilNextSunday);

        return {
            start: `${nextMonday.getDate().toString().padStart(2, '0')}/${(nextMonday.getMonth() + 1).toString().padStart(2, '0')}/${nextMonday.getFullYear()}`,
            end: `${nextSunday.getDate().toString().padStart(2, '0')}/${(nextSunday.getMonth() + 1).toString().padStart(2, '0')}/${nextSunday.getFullYear()}`,
        };
    }, []);

    const { start, end } = getNextWeekDateRange();

    const fetchData = useCallback(async (url, options = {}) => {
        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                ...options
            });
            if (response.status === 200) {
                return await response.json();
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        } catch (error) {
            console.error(`Error fetching data from ${url}:`, error);
            return null;
        }
    }, []);

    useEffect(() => {
        const getCourseTypeList = async () => {
            const data = await fetchData(`${baseUrl}/kidsai/courseType/getList`);
            if (data) setCourseTypeList(data.result);
        };
        getCourseTypeList();
    }, [baseUrl, fetchData]);

    useEffect(() => {
        if (selectedCourseType) {
            const getCourseListByType = async () => {
                const data = await fetchData(`${baseUrl}/kidsai/course/findCoursesByType?courseTypeId=${encodeURIComponent(selectedCourseType.id)}`);
                if (data) setCourseList(data.result);
            };
            getCourseListByType();
        }
    }, [baseUrl, selectedCourseType, fetchData]);

    useEffect(() => {
        if (searchQuery) {
            const getCourseListByName = async () => {
                const data = await fetchData(`${baseUrl}/kidsai/course/findCoursesByName?name=${encodeURIComponent(searchQuery)}`);
                if (data) setCourseList(data.result);
            };
            getCourseListByName();
        }
    }, [baseUrl, searchQuery, fetchData]);

    const handleSearch = (event, value) => {
        setSearchQuery(value);
    };

    const handleCourseClick = (course) => {
        setSelectedCourseId(course.id);
    };

    const handleCellClick = (cls, isChosen) => {
        if (!isChosen) {
            setTempSelectedClass(cls);
            setOpen(true);
        }
    };

    const handleConfirm = async () => {
        if (tempSelectedClass) {
            try {
                const response = await fetch(`${baseUrl}/kidsai/userClass/save?classId=${encodeURIComponent(tempSelectedClass.classId)}&userId=${encodeURIComponent(userId)}&isDelete=${encodeURIComponent(false)}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'include'
                });

                if (response.status === 200) {
                    setOpen(false);
                    const data = await response.json();
                    console.log(data);

                    setChosenClasses(prevChosenClasses => [...prevChosenClasses, tempSelectedClass.classId]);
                    setClasses(prevClasses => prevClasses.map(cls =>
                        cls.classId === tempSelectedClass.classId ? { ...cls, isDeleted: false } : cls
                    ));
                    alert("Class saved successfully");
                } else {
                    throw new Error('Failed to save class');
                }
            } catch (error) {
                console.error("Error saving user class:", error);
                alert("Failed to save class");
            } finally {
                setTempSelectedClass(null);
            }
        }
    };

    const handleClose = async () => {
        setOpen(false);
        setTempSelectedClass(null);
    };

    return (
        <div className={styles.container}>
            <Card className={styles.leftPage}>
                <div className={styles.dropDownBox}>
                    <Autocomplete
                        value={selectedCourseType}
                        onChange={(event, newValue) => setSelectedCourseType(newValue)}
                        options={courseTypeList}
                        getOptionLabel={(option) => option.name}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Select Course Type"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                        sx={{ width: 350 }}
                    />
                </div>
                <div className={styles.searchWrapper}>
                    <Autocomplete
                        freeSolo
                        disableClearable
                        options={courseList.map(course => course.name)}
                        onInputChange={handleSearch}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Search Courses"
                                InputProps={{
                                    ...params.InputProps,
                                    type: 'search',
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <SearchIcon />
                                        </InputAdornment>
                                    ),
                                }}
                            />
                        )}
                        sx={{ width: 350 }}
                    />
                </div>
                {courseList.length > 0 && (
                    <div className={styles.list}>
                        <List>
                            {courseList.map((course) => (
                                <ListItem
                                    key={course.id}
                                    disablePadding
                                    button
                                    onClick={() => handleCourseClick(course)}
                                    className={styles.listItem}
                                >
                                    <ListItemText primary={course.name} />
                                </ListItem>
                            ))}
                        </List>
                    </div>
                )}

            </Card>
            <Card className={styles.rightPage}>
                <div className={styles.dateRange}>
                    <CalendarTodayIcon />
                    <span>{`${start} - ${end}`}</span>
                </div>
                <ClassSchedule
                    flag={0}
                    startDate={start}
                    endDate={end}
                    courseId={selectedCourseId}
                    setClasses={setClasses}
                    chosenClasses={chosenClasses}
                    setChosenClasses={setChosenClasses}
                    onCellClick={handleCellClick}
                    tooltipMessage="Click to select this class"
                    alwaysShowTooltip={false}
                />
                <Dialog open={open} onClose={handleClose}>
                    <DialogTitle>
                        Confirm Selection
                    </DialogTitle>
                    <DialogContent>
                        Are you sure you want to confirm this selection?
                        {tempSelectedClass && (
                            <DialogContentText>
                                {`Course: ${tempSelectedClass.name}`}
                                <br />
                                {`Location: ${tempSelectedClass.location}`}
                                <br />
                                {`Time: ${tempSelectedClass.startTime} - ${tempSelectedClass.endTime}`}
                            </DialogContentText>
                        )}
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setOpen(false)} color="primary">
                            Cancel
                        </Button>
                        <Button onClick={handleConfirm} color="primary">
                            Confirm
                        </Button>
                    </DialogActions>
                </Dialog>
            </Card>
        </div>
    );
}

export default CourseSelectionPage;