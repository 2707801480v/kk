import React, { useEffect, useRef, useState } from 'react';
import { Card, Container, Paper, Typography, Button } from "@mui/material";
import styles from "./ChatgptPage.module.css";
import ChatgptCard from '../components/ChatgptCard';
import AIText from '../components/AIText';
import TextBox from '../components/TextBox';
import GptHistory from "../components/GptHistory";

function ChatgptPage() {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const userId = sessionStorage.getItem('userId');
    const [input, setInput] = useState('');
    const [messages, setMessages] = useState([]);
    const [prompt, setPrompt] = useState('');
    const [history, setHistory] = useState(() => {
        const savedHistory = sessionStorage.getItem('chatHistory');
        if (savedHistory) {
            return JSON.parse(savedHistory);
        } else {
            const defaultChat = {
                id: Date.now(),
                title: "New Chat",
                messages: [],
            };
            sessionStorage.setItem('chatHistory', JSON.stringify([defaultChat]));
            return [defaultChat];
        }
    });
    const [currentChatId, setCurrentChatId] = useState(history[0].id);
    const [showDefaultQuestions, setShowDefaultQuestions] = useState(true);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        const chat = history.find(chat => chat.id === currentChatId);
        setMessages(chat ? chat.messages : []);
    }, [history, currentChatId]);

    useEffect(() => {
        sessionStorage.setItem('chatHistory', JSON.stringify(history));
    }, [history]);

    const generateChatTitle = (messages) => {
        const title = messages.map(msg => msg.text).join(' ').substring(0, 20);
        return title.length > 20 ? `${title}...` : title;
    };

    const handleNewChat = () => {
        const newChat = {
            id: Date.now(),
            title: "New Chat",
            messages: [],
        };

        setCurrentChatId(newChat.id);
        setMessages([]);
        setShowDefaultQuestions(true);
        return newChat.id;
    };

    const handleSelectChat = (chatId) => {
        setCurrentChatId(chatId);
        setShowDefaultQuestions(false); // Hide default questions when a chat is selected
    };

    const handleSelectQuestion = async (question) => {
        const newChatId = handleNewChat();
        setCurrentChatId(newChatId);
        setMessages([{ sender: 'user', text: question }]);
        setInput('');
        await handleSubmit(question, newChatId);
    };

    const handleSubmit = async (overrideInput, chatIdOverride) => {
        const messageText = overrideInput || input;
        const targetChatId = chatIdOverride || currentChatId;
        if (messageText.trim() === '') return;
        setInput('');

        const userMessage = { sender: 'user', text: messageText };
        const newMessages = chatIdOverride ? [userMessage] : [...messages, userMessage];

        setMessages(newMessages);
        setShowDefaultQuestions(false);

        if (chatIdOverride) {
            const updatedHistory = [...history, { id: chatIdOverride, title: generateChatTitle(newMessages), messages: newMessages }];
            setHistory(updatedHistory);
        }

        try {
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer sk-proj-4nZ3E1TJFG6vLrraLEMGT3BlbkFJA3vLKCJt3yLpRgKYPoWF`,
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [
                        { role: 'system', content: 'You are a helpful assistant.' },
                        ...newMessages.map(msg => ({
                            role: msg.sender === 'user' ? 'user' : 'assistant',
                            content: msg.text,
                        })),
                    ],
                }),
            });

            saveUserBehaviour();
            const data = await response.json();
            if (response.ok) {
                const botMessage = {
                    sender: 'assistant',
                    text: data.choices[0].message.content,
                };
                setPrompt(botMessage.text);
                const updatedMessages = [...newMessages, botMessage];
                setMessages(updatedMessages);

                if (updatedMessages.length > 0) {
                    const updatedHistory = history.some(chat => chat.id === targetChatId)
                        ? history.map(chat =>
                            chat.id === targetChatId ? { ...chat, messages: updatedMessages, title: generateChatTitle(updatedMessages) } : chat
                        )
                        : [...history, { id: targetChatId, title: generateChatTitle(updatedMessages), messages: updatedMessages }];
                    setHistory(updatedHistory);
                }
            } else {
                throw new Error(data.error.message);
            }
        } catch (error) {
            console.error("Error calling GPT-3.5 API:", error);
            const errorMessage = {
                sender: 'assistant',
                text: "Sorry, something went wrong. Please try again later.",
            };
            setMessages(prevMessages => [...prevMessages, errorMessage]);
        }
    };

    const saveUserBehaviour = async () => {
        const saveRequestBody = {
            api: "v1/chat/completions",
            endpoint: "api.openai.com",
            userId: userId,
            prompt: prompt.length > 120 ? prompt.substring(0, 120) : prompt
        };
        console.log("saveRequestBody:", saveRequestBody);
        try {
            console.log('Base URL:', baseUrl);
            const response = await fetch(`${baseUrl}/kidsai/callAI/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(saveRequestBody),
                credentials: 'include'
            });
            console.log("Save API response:", response);
            if (response.status === 200) {
                console.log("Save user behaviour is successful, record: ", JSON.stringify(saveRequestBody));
            }
        } catch (saveError) {
            console.error('Error calling save API:', saveError);
        }
    }


    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    return (
        <React.Fragment>
            <div className={styles.container}>
                <div className={styles.sidebar}>
                    <Button variant="contained" color="primary" onClick={handleNewChat}>New Chat</Button>
                    <GptHistory searchHistory={history} onSelectChat={handleSelectChat} />
                </div>
                <Card className={styles.gptText}>
                    <AIText />
                    <Container className={styles.rightCard}>
                        {showDefaultQuestions && <ChatgptCard onSelectQuestion={handleSelectQuestion} />}
                        <div className={styles.chatBox}>
                            {messages.map((msg, index) => (
                                <div
                                    key={index}
                                    className={`${styles.messageContainer} ${msg.sender === 'user' ? styles.userMessage : styles.botMessage
                                        }`}
                                >
                                    <Paper elevation={3} className={styles.messagePaper}>
                                        <Typography variant="body1">{msg.text}</Typography>
                                    </Paper>
                                </div>
                            ))}
                            <div ref={messagesEndRef} />
                        </div>
                        <TextBox
                            inputValue={input}
                            setInputValue={setInput}
                            handleSubmit={handleSubmit}
                        />
                    </Container>
                </Card>
            </div>
        </React.Fragment>
    );
}
export default ChatgptPage;