import React, { useState } from 'react';
import { Card, List, ListItem, ListItemText } from '@mui/material';
import styles from './AccountPage.module.css';
import PersonalInfo from './PersonalInformation';
import EnrollCourse from './EnrollCourse';
import CancelClassSchedule from '../components/CancelClassSchedule';
import RechargeHistoryPage from './RechargeHistoryPage';

function AccountPage() {
    const [value, setValue] = useState(0);

    const handleChange = (index) => {
        setValue(index);
    };

    const renderComponent = () => {
        switch (value) {
            case 0:
                return <PersonalInfo />;
            case 1:
                return <CancelClassSchedule />;
            case 2:
                return <EnrollCourse />;
            case 3:
                return <RechargeHistoryPage />;
            default:
                return <PersonalInfo />;
        }
    }

    return (
        <div className={styles.container}>
            <Card className={styles.sidebar}>
                <List>
                    {['Info', 'Class Schedule', 'Enroll course', 'Recharge history'].map((text, index) => (
                        <ListItem
                            button
                            key={text}
                            onClick={() => handleChange(index)}
                            className={value === index ? styles.selectedItem : ''}
                        >
                            <ListItemText primary={text} />
                        </ListItem>
                    ))}
                </List>
            </Card>
            {renderComponent()}
        </div>
    );
}

export default AccountPage;