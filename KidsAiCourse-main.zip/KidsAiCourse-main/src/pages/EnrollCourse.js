import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    CircularProgress
} from '@mui/material';
import { styled } from '@mui/material/styles';
import ListIcon from '@mui/icons-material/List';
import styles from './EnrollCourse.module.css';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    fontWeight: 'bold',
    textAlign: 'center',
}));

const EnrollCourse = () => {
    const baseUrl = process.env.REACT_APP_BASE_URL;
    const [classInfo, setClassInfo] = useState(null);
    const [selectedCourses, setSelectedCourses] = useState([]);
    const [loading, setLoading] = useState(true);
    const userId = sessionStorage.getItem('userId');

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const response = await fetch(`${baseUrl}/kidsai/userClass/getTotalInfo?userId=${encodeURIComponent(userId)}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include'
                });
                if (response.status === 200) {
                    const data = await response.json();
                    setClassInfo(data.result);
                }
            } catch (error) {
                console.error('Error getTotalInfo:', error);
            }

            try {
                const response = await fetch(`${baseUrl}/kidsai/userClass/getUserCourses?userId=${encodeURIComponent(userId)}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include'
                });
                if (response.status === 200) {
                    const data = await response.json();
                    setSelectedCourses(data.result);
                }
            } catch (error) {
                console.error('Error getUserCourses:', error);
            }
            setLoading(false);
        };
        fetchData();
    }, []);

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress />
            </Box>
        );
    }

    return (
        <Box>
            {classInfo && (
                <TableContainer component={Paper} sx={{ mb: 4 }}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <StyledTableCell>Total Class</StyledTableCell>
                                <StyledTableCell>Completed Class</StyledTableCell>
                                <StyledTableCell>Remaining Class</StyledTableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            <TableRow>
                                <StyledTableCell>{classInfo.totalClass}</StyledTableCell>
                                <StyledTableCell>{classInfo.completedClass}</StyledTableCell>
                                <StyledTableCell sx={{ color: 'error.main' }}>{classInfo.remainingClass}</StyledTableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </TableContainer>
            )}

            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <ListIcon sx={{ mr: 1 }} />
                    <Typography variant="h6">Selected Course</Typography>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <StyledTableCell>Course Type</StyledTableCell>
                            <StyledTableCell>Course Name</StyledTableCell>
                            <StyledTableCell>Class Name</StyledTableCell>
                            <StyledTableCell>Amount</StyledTableCell>
                            <StyledTableCell>Status</StyledTableCell>
                            <StyledTableCell>Selected Class Date</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {selectedCourses.map((course, index) => (
                            <TableRow key={index}>
                                <StyledTableCell>{course.courseType}</StyledTableCell>
                                <StyledTableCell>{course.courseName}</StyledTableCell>
                                <StyledTableCell>{course.className}</StyledTableCell>
                                <StyledTableCell>{course.amount}</StyledTableCell>
                                <StyledTableCell>{course.status}</StyledTableCell>
                                <StyledTableCell>{course.selectedClassDate}</StyledTableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    );
};

export default EnrollCourse;