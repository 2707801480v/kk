# KidsAiCourseBackend

Deployed Swagger UI:
http://43.133.138.207:8082/kidsai/swagger-ui.html