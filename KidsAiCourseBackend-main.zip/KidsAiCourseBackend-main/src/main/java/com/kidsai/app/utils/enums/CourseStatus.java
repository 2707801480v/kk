package com.kidsai.app.utils.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public enum CourseStatus {
    UNPUBLISHED(0),
    PUBLISHED(1);

    private final int value;

    CourseStatus(int value) {
        this.value = value;
    }

    public static CourseStatus fromValue(int value) {
        for (CourseStatus status : values()) {
            if (status.value == value) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid CourseStatus value: " + value);
    }

    public static class StatusDTO {
        private int code;
        private String name;
        private String description;

        public StatusDTO(CourseStatus status) {
            this.code = status.getValue();
            this.name = status.name();
        }

        // Getters
        public int getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }
    }

    public static List<CourseStatus.StatusDTO> getAllStatuses() {
        return Arrays.stream(CourseStatus.values())
                .map(CourseStatus.StatusDTO::new)
                .collect(Collectors.toList());
    }
}
