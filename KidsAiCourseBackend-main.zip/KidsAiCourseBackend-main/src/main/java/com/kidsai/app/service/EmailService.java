package com.kidsai.app.service;

import com.kidsai.app.utils.exceptions.ResultResponse;

public interface EmailService {

    ResultResponse sendEmail(String to);

    ResultResponse checkMail(String email);

    ResultResponse validMail(String code, String uuid);
}


