package com.kidsai.app.utils.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum RepeatFrequencyEnum {
    NONE(1, "No Repeat"),
    DAILY(2, "Daily"),
    WEEKLY(3, "Weekly"),
    MONTHLY(4, "Monthly");

    private final Integer code;
    private final String description;

    private static final Map<Integer, RepeatFrequencyEnum> CODE_MAP = Arrays.stream(values())
            .collect(Collectors.toMap(RepeatFrequencyEnum::getCode, e -> e));

    RepeatFrequencyEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    public Integer getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static RepeatFrequencyEnum getByCode(Integer code) {
        RepeatFrequencyEnum result = CODE_MAP.get(code);
        if (result == null) {
            throw new IllegalArgumentException("No RepeatFrequencyEnum exists for code: " + code);
        }
        return result;
    }

    public static boolean isValidCode(Integer code) {
        return CODE_MAP.containsKey(code);
    }

    @Override
    public String toString() {
        return String.format("%s(code=%d, description='%s')", name(), code, description);
    }
}