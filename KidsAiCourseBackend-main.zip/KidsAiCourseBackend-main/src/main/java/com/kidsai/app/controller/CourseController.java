package com.kidsai.app.controller;

import com.kidsai.app.models.request.CourseRequest;
import com.kidsai.app.service.CourseService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    private CourseService courseService;

    @GetMapping("/findCoursesByType")
    public ResponseEntity<ResultResponse> findCoursesByType(Long courseTypeId) {
        ResultResponse result = courseService.findCoursesByType(courseTypeId);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@Validated @RequestBody CourseRequest courseRequest) {
        ResultResponse result = courseService.save(courseRequest);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/findCoursesByName")
    public ResponseEntity<ResultResponse> findCoursesByName(@NotBlank @RequestParam String name) {
        ResultResponse result = courseService.findCoursesByName(name);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/findAll")
    public ResponseEntity<ResultResponse> findAll() {
        ResultResponse result = courseService.findAll();
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/findCourseStatus")
    public ResponseEntity<ResultResponse> findStatusList() {
        ResultResponse result = courseService.findStatusList();
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PostMapping("/saveStatus")
    public ResponseEntity<ResultResponse> saveStatus(@RequestParam Long courseId, @RequestParam Integer status) {
        ResultResponse result = courseService.saveStatus(courseId, status);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<ResultResponse> delete(@RequestParam Long id) {
        ResultResponse result = courseService.delete(id);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<ResultResponse> editCourse(@PathVariable Long id, @Validated @RequestBody CourseRequest courseRequest) {
        ResultResponse result = courseService.editCourse(id, courseRequest);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/search")
    public ResponseEntity<ResultResponse> searchCourses(@RequestParam(required = false) Long courseTypeId,
                                                        @RequestParam(required = false) Integer status) {
        ResultResponse response = courseService.searchCourses(courseTypeId, status);
        if (response.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/findById")
    public ResponseEntity<ResultResponse> findById(@RequestParam Long id) {
        ResultResponse result = courseService.findById(id);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }
}
