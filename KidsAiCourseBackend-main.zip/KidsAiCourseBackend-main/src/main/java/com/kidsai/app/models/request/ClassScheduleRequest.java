package com.kidsai.app.models.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClassScheduleRequest {
    @NotNull
    private Long classId;

    @NotNull
    public List<ScheduleItem> scheduleItems;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ScheduleItem {
        @NotNull
        private LocalDate date;

        @NotNull
        private LocalTime startTime;

        @NotNull
        private LocalTime endTime;
    }
}