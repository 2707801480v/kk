package com.kidsai.app.models;

import com.kidsai.app.utils.enums.Role;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "email")
        })
@Getter
@Setter
@NoArgsConstructor
public class User extends BaseEntity {

    @NotBlank
    @Size(max = 20)
    @Column(name = "username")
    private String username;
    @NotBlank
    @Size(max = 50)
    @Email
    private String email;

    @NotBlank
    @Pattern(regexp = "^04\\d{8}$", message = "Invalid Australian mobile number format")
    private String mobile;

    @NotBlank
    @Size(max = 120)
    private String password;

    @Column(nullable = false)
    private boolean status;

    /**
     * status is logged in, 0: not logged in, 1: logged in
     */

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Column(nullable = false)
    @Min(value = 0)
    private BigDecimal balance;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<UserClass> userClasses = new HashSet<>();

    public User(String email, String password, String username, String mobile, Role role) {
        this.email = email;
        this.password = password;
        this.username = username;
        this.mobile = mobile;
        this.role = role;
        this.status = false;
        this.balance = BigDecimal.valueOf(0);
    }
}
