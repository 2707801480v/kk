package com.kidsai.app.controller;

import com.kidsai.app.models.request.ClassScheduleSaveRequest;
import com.kidsai.app.models.request.ClassScheduleSingleRequest;
import com.kidsai.app.service.ClassScheduleService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/class-schedule")
public class ClassScheduleController {

    @Autowired
    private ClassScheduleService classScheduleService;

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@Validated @RequestBody ClassScheduleSaveRequest classScheduleRequest) {
        ResultResponse result = classScheduleService.save(classScheduleRequest);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/findByClassId")
    public ResponseEntity<ResultResponse> findSchedulesByClassId(@RequestParam Long classId) {
        ResultResponse result = classScheduleService.findSchedulesByClassId(classId);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<ResultResponse> deleteSchedule(@RequestParam Long id) {
        ResultResponse result = classScheduleService.delete(id);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PutMapping("/edit")
    public ResponseEntity<ResultResponse> editSchedule(@RequestBody ClassScheduleSingleRequest classScheduleRequest) {
        ResultResponse result = classScheduleService.edit(classScheduleRequest);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }
}