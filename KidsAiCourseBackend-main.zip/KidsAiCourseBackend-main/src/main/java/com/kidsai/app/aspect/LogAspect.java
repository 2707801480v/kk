package com.kidsai.app.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogAspect {
    private static final Logger logger = LoggerFactory.getLogger(LogAspect.class);

    // 拦截所有Controller下的方法
    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void controllerLog() {
    }

    @Around("controllerLog()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();

        // 打印入参
        logger.info("Entering in Method :  {} of Class : {}", signature.getMethod().getName(), joinPoint.getTarget().getClass().getSimpleName());
        Object[] args = joinPoint.getArgs();
        if (args != null) {
            for (Object arg : args) {
                logger.info("Argument value - {}", arg);
            }
        }

        Object result;
        try {
            result = joinPoint.proceed(); // 方法执行
        } catch (Exception e) {
            logger.error("An exception has been thrown in {}", signature.getMethod().getName());
            logger.error("Cause : {}", e.getCause());
            throw e;
        }

        // 打印响应结果
        logger.info("Method return value : {}", result);
        logger.info("Exiting from Method :  {} of Class : {}", signature.getMethod().getName(), joinPoint.getTarget().getClass().getSimpleName());

        return result;
    }

    @AfterThrowing(pointcut = "controllerLog()", throwing = "ex")
    public void logException(JoinPoint joinPoint, Exception ex) {
        logger.error("Exception occurred in method: {}, Message: {}", joinPoint.getSignature(), ex.getMessage());
    }
}
