package com.kidsai.app.models.response;


import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class UserRechargeResponse {
    private Long userId;
    private BigDecimal balance;
}
