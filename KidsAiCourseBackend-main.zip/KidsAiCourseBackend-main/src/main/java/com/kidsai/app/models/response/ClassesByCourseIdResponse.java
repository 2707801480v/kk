package com.kidsai.app.models.response;

import com.kidsai.app.utils.enums.ClassStatus;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ClassesByCourseIdResponse {

    private Long classId;
    private String name;
    private String location;
    private List<ClassScheduleResponse> schedules;
    private BigDecimal price;
    private String time;
    private Long courseId;
    private Integer available;
    private Long userClassId;
    private Boolean isDeleted;
    private ClassStatus status;
}
