package com.kidsai.app.service;

import com.kidsai.app.models.request.ClassScheduleSaveRequest;
import com.kidsai.app.models.request.ClassScheduleSingleRequest;
import com.kidsai.app.utils.exceptions.ResultResponse;

public interface ClassScheduleService {

    ResultResponse save(ClassScheduleSaveRequest classScheduleRequest);

    ResultResponse findSchedulesByClassId(Long classId);

    ResultResponse delete(Long id);

    ResultResponse edit(ClassScheduleSingleRequest classScheduleRequest);
}
