package com.kidsai.app.utils.exceptions;

import com.google.gson.Gson;
import org.springframework.http.HttpStatus;

public class ResultResponse {
    /**
     * response code
     */
    private String code;

    /**
     * response message
     */
    private String message;

    /**
     * response result
     */
    private Object result;

    public ResultResponse() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    /**
     * success
     *
     * @return
     */
    public static ResultResponse success() {
        return success(null);
    }

    /**
     * success
     *
     * @param data
     * @return
     */
    public static ResultResponse success(Object data) {
        ResultResponse rb = new ResultResponse();
        rb.setCode(String.valueOf(HttpStatus.OK.value()));
        rb.setMessage(HttpStatus.OK.getReasonPhrase());
        rb.setResult(data);
        return rb;
    }

    /**
     * fail
     */
    public static ResultResponse error(BaseErrorInfoInterface errorInfo) {
        ResultResponse rb = new ResultResponse();
        rb.setCode(errorInfo.getResultCode());
        rb.setMessage(errorInfo.getResultMsg());
        rb.setResult(null);
        return rb;
    }

    /**
     * fail
     */
    public static ResultResponse error(String code, String message) {
        ResultResponse rb = new ResultResponse();
        rb.setCode(code);
        rb.setMessage(message);
        rb.setResult(null);
        return rb;
    }

    /**
     * fail
     */
    public static ResultResponse error(String message) {
        ResultResponse rb = new ResultResponse();
        rb.setCode("-1");
        rb.setMessage(message);
        rb.setResult(null);
        return rb;
    }

    @Override
    public String toString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}
