package com.kidsai.app.controller;

import com.kidsai.app.service.RechargeHistoryService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/rechargeHistory")
public class RechargeHistoryController {

    @Autowired
    private RechargeHistoryService rechargeHistoryService;

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@Validated @RequestParam Long userId, @RequestParam BigDecimal rechargeAmount) {
        ResultResponse result = rechargeHistoryService.save(userId, rechargeAmount);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/getList")
    public ResponseEntity<ResultResponse> getList(@RequestParam Long userId) {
        ResultResponse result = rechargeHistoryService.findAllByUserId(userId);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }
}
