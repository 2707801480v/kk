package com.kidsai.app.models.response;

import com.kidsai.app.utils.enums.ClassStatus;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ClassResponse {
    private Long id;
    private String name;
    private String location;
    private Integer available;
    private BigDecimal price;
    private Long courseId;
    private ClassStatus classStatus;
}
