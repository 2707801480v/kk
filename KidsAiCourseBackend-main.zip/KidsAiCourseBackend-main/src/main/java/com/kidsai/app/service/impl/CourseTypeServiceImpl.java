package com.kidsai.app.service.impl;

import com.kidsai.app.models.CourseType;
import com.kidsai.app.models.request.CourseTypeRequest;
import com.kidsai.app.models.response.CourseTypeResponse;
import com.kidsai.app.repository.CourseTypeRepository;
import com.kidsai.app.service.CourseTypeService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CourseTypeServiceImpl implements CourseTypeService {

    @Autowired
    private CourseTypeRepository courseTypeRepository;

    @Override
    public ResultResponse getList() {
        List<CourseType> list = courseTypeRepository.findAll()
                .stream()
                .filter(courseType -> !courseType.getIsDeleted())
                .collect(Collectors.toList());
        return ResultResponse.success(list);
    }

    @Override
    public ResultResponse save(CourseTypeRequest courseTypeRequest) {
        if (courseTypeRequest.getName().isBlank() || courseTypeRequest.getName().isEmpty()) {
            return ResultResponse.error("Error: CourseType name cannot be empty.");
        }
        Optional<CourseType> courseTypeOptional = courseTypeRepository.findByName(courseTypeRequest.getName());
        if (courseTypeOptional.isPresent()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: CourseType already exists.");
        }
        CourseType courseType = new CourseType();
        courseType.setName(courseTypeRequest.getName());
        courseType.setDescription(courseTypeRequest.getDescription());
        CourseType savedCourseType = courseTypeRepository.save(courseType);
        return ResultResponse.success(savedCourseType);
    }

    @Override
    public ResultResponse edit(CourseTypeRequest courseTypeRequest) {
        if (Objects.isNull(courseTypeRequest.getId())) {
            return ResultResponse.error("Error: CourseType Id cannot be empty.");
        }
        if (Objects.isNull(courseTypeRequest.getName())) {
            return ResultResponse.error("Error: CourseType name cannot be empty.");
        }
        Optional<CourseType> optionalCourseType = courseTypeRepository.findById(courseTypeRequest.getId());
        if (optionalCourseType.isPresent()) {
            CourseType courseType = optionalCourseType.get();
            courseType.setName(courseTypeRequest.getName());
            courseType.setDescription(courseTypeRequest.getDescription());
            courseTypeRepository.save(courseType);
            return ResultResponse.success(courseType);
        } else {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: CourseType not found.");
        }
    }

    @Override
    public ResultResponse delete(Long id) {
        Optional<CourseType> optionalCourseType = courseTypeRepository.findById(id);
        if (optionalCourseType.isPresent()) {
            CourseType courseType = optionalCourseType.get();
            courseType.setIsDeleted(true);
            courseTypeRepository.save(courseType);
            return ResultResponse.success("CourseType deleted successfully");
        } else {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: CourseType not found.");
        }
    }

    @Override
    public ResultResponse findByName(String name) {
        Optional<List<CourseType>> fuzzyByNameOptional = courseTypeRepository.findFuzzyByName(name);
        if (fuzzyByNameOptional.isEmpty()) {
            return ResultResponse.success("No course types found for the given name");
        }
        List<CourseTypeResponse> courseTypeResponseList = fuzzyByNameOptional.get().stream()
                .filter(courseType -> !Boolean.TRUE.equals(courseType.getIsDeleted()))
                .map(courseType -> {
                    CourseTypeResponse response = new CourseTypeResponse();
                    response.setId(courseType.getId());
                    response.setName(courseType.getName());
                    response.setDescription(courseType.getDescription());
                    return response;
                }).collect(Collectors.toList());
        return ResultResponse.success(courseTypeResponseList);
    }
}
