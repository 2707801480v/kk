package com.kidsai.app.service.impl;

import com.kidsai.app.models.ClassEntity;
import com.kidsai.app.models.ClassSchedule;
import com.kidsai.app.models.request.ClassScheduleSaveRequest;
import com.kidsai.app.models.request.ClassScheduleSingleRequest;
import com.kidsai.app.models.response.ClassScheduleByIdResponse;
import com.kidsai.app.repository.ClassRepository;
import com.kidsai.app.repository.ClassScheduleRepository;
import com.kidsai.app.service.ClassScheduleService;
import com.kidsai.app.utils.enums.RepeatFrequencyEnum;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClassScheduleServiceImpl implements ClassScheduleService {

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private ClassScheduleRepository classScheduleRepository;

    @Override
    @Transactional
    public ResultResponse save(ClassScheduleSaveRequest classScheduleRequest) {
        if (Objects.isNull(classScheduleRequest)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: request cannot be null or empty.");
        }
        if (Objects.isNull(classScheduleRequest.getClassId()) || Objects.isNull(classScheduleRequest.getDate()) ||
                Objects.isNull(classScheduleRequest.getStartTime()) || Objects.isNull(classScheduleRequest.getEndTime()) ||
                Objects.isNull(classScheduleRequest.getRepeatFrequency())) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: request parameters cannot be null or empty.");
        }

        Optional<ClassEntity> classEntityOptional = classRepository.findByIdAndIsDeletedFalse(classScheduleRequest.getClassId());
        if (classEntityOptional.isEmpty()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: class not found.");
        }

        LocalDate startDate = classScheduleRequest.getDate();
        LocalDate endDate = classScheduleRequest.getRepeatEndDate();

        RepeatFrequencyEnum repeatFrequency;
        try {
            repeatFrequency = RepeatFrequencyEnum.getByCode(classScheduleRequest.getRepeatFrequency());
        } catch (IllegalArgumentException e) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Invalid repeat frequency code.");
        }

        if (repeatFrequency != RepeatFrequencyEnum.NONE && endDate == null) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: repeat end date must be set for repeating schedules.");
        }

        if (endDate != null && endDate.isBefore(startDate)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: repeat end date cannot be earlier than start date.");
        }

        switch (repeatFrequency) {
            case NONE -> saveClassSchedule(classScheduleRequest, classEntityOptional.get(), startDate);
            case DAILY -> {
                for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
                    saveClassSchedule(classScheduleRequest, classEntityOptional.get(), date);
                }
            }
            case WEEKLY -> {
                for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusWeeks(1)) {
                    saveClassSchedule(classScheduleRequest, classEntityOptional.get(), date);
                }
            }
            case MONTHLY -> {
                for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusMonths(1)) {
                    saveClassSchedule(classScheduleRequest, classEntityOptional.get(), date);
                }
            }
            default -> {
                return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Invalid repeat frequency.");
            }
        }
        return ResultResponse.success();
    }

    private void saveClassSchedule(ClassScheduleSaveRequest request, ClassEntity classEntity, LocalDate date) {
        ClassSchedule classSchedule = new ClassSchedule();
        BeanUtils.copyProperties(request, classSchedule);
        classSchedule.setIsDeleted(false);
        classSchedule.setClassEntity(classEntity);
        classSchedule.setClassDate(date);
        classSchedule.setAvailable(request.getAvailable());
        classScheduleRepository.save(classSchedule);
    }

    @Override
    public ResultResponse findSchedulesByClassId(Long classId) {
        if (Objects.isNull(classId)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: classId cannot be null.");
        }

        List<ClassSchedule> classSchedules = classScheduleRepository.findByClassEntityId(classId);

        if (classSchedules.isEmpty()) {
            return ResultResponse.success(new ClassScheduleByIdResponse(classId, new ArrayList<>()));
        }

        ClassScheduleByIdResponse response = new ClassScheduleByIdResponse();
        response.setClassId(classId);
        List<ClassScheduleByIdResponse.ScheduleItem> scheduleItems = classSchedules.stream()
                .filter(schedule -> !schedule.getIsDeleted())
                .map(schedule -> new ClassScheduleByIdResponse.ScheduleItem(
                        schedule.getId(),
                        schedule.getClassDate(),
                        schedule.getStartTime(),
                        schedule.getEndTime(),
                        schedule.getAvailable()
                ))
                .collect(Collectors.toList());
        response.setScheduleItems(scheduleItems);

        return ResultResponse.success(response);
    }

    @Override
    public ResultResponse delete(Long id) {
        Optional<ClassSchedule> classScheduleOptional = classScheduleRepository.findById(id);
        if (classScheduleOptional.isPresent()) {
            ClassSchedule classSchedule = classScheduleOptional.get();
            classSchedule.setIsDeleted(true);
            classScheduleRepository.save(classSchedule);
            return ResultResponse.success("Class schedule deleted successfully");
        } else {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class schedule not found.");
        }
    }

    @Override
    public ResultResponse edit(ClassScheduleSingleRequest classScheduleRequest) {
        if (Objects.isNull(classScheduleRequest.getId())) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class schedule id cannot be empty.");
        }
        if (Objects.isNull(classScheduleRequest.getDate()) || Objects.isNull(classScheduleRequest.getStartTime()) || Objects.isNull(classScheduleRequest.getEndTime())) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class schedule parameters cannot be empty.");
        }
        Optional<ClassSchedule> classScheduleOptional = classScheduleRepository.findByIdAndIsDeletedFalse(classScheduleRequest.getId());
        if (classScheduleOptional.isEmpty()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class schedule not found.");
        }

        ClassSchedule classSchedule = new ClassSchedule();
        BeanUtils.copyProperties(classScheduleRequest, classSchedule);
        classSchedule.setClassDate(classScheduleRequest.getDate());
        classSchedule.setId(classScheduleRequest.getId());
        classSchedule.setClassEntity(classScheduleOptional.get().getClassEntity());
        classSchedule.setIsDeleted(false);
        classSchedule.setAvailable(classScheduleRequest.getAvailable());
        classScheduleRepository.save(classSchedule);
        return ResultResponse.success(classScheduleRequest.getId());
    }
}
