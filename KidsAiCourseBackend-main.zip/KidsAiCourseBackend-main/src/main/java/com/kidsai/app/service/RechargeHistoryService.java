package com.kidsai.app.service;

import com.kidsai.app.utils.exceptions.ResultResponse;

import java.math.BigDecimal;

public interface RechargeHistoryService {

    ResultResponse save(Long userId, BigDecimal rechargeAmount);

    ResultResponse findAllByUserId(Long userId);

}
