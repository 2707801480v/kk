package com.kidsai.app.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class EmailConfig {
    @Value("${maileroo.api.send-key}")
    private String sendKey;

    @Value("${maileroo.api.check-key}")
    private String checkKey;

    @Value("${maileroo.api.send-endpoint}")
    private String sendEndpoint;

    @Value("${maileroo.api.check-endpoint}")
    private String checkEndpoint;

    @Value("${maileroo.subject}")
    private String subject;

    @Value("${maileroo.from}")
    private String from;
}
