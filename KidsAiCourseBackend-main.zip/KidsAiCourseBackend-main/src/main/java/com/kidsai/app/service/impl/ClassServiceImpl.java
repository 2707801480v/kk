package com.kidsai.app.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kidsai.app.models.ClassEntity;
import com.kidsai.app.models.Course;
import com.kidsai.app.models.request.ClassEditRequest;
import com.kidsai.app.models.request.ClassRequest;
import com.kidsai.app.models.response.ClassResponse;
import com.kidsai.app.models.response.ClassScheduleResponse;
import com.kidsai.app.models.response.ClassesByCourseIdResponse;
import com.kidsai.app.models.response.ClassesByTypeResponse;
import com.kidsai.app.repository.ClassRepository;
import com.kidsai.app.repository.CourseRepository;
import com.kidsai.app.repository.UserClassRepository;
import com.kidsai.app.service.ClassService;
import com.kidsai.app.utils.enums.ClassStatus;
import com.kidsai.app.utils.exceptions.ResultResponse;
import com.mysql.cj.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClassServiceImpl implements ClassService {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Logger logger = LoggerFactory.getLogger(ClassServiceImpl.class);

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private UserClassRepository userClassRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public ResultResponse findByCourseIdAndDateRange(Long courseId, Long userId, LocalDate startDate, LocalDate endDate) {
        if (Objects.isNull(courseId)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: courseId cannot be empty");
        }

//        List<ClassEntity> classList = classRepository.findByCourseIdAndDateRange(courseId, startDate, endDate);
//        if (classList.isEmpty()) {
//            return ResultResponse.success("No classes found for the given course id");
//        }
//        List<UserClass> userClasses = userClassRepository.findByUserIdAndClassEntityIn(userId, classList);
//
//        Map<Long, UserClassIsDeletedResponse> classIdToUserClassInfoMap = userClasses.stream()
//                .collect(Collectors.toMap(
//                        uc -> uc.getClassEntity().getId(),
//                        uc -> new UserClassIsDeletedResponse(uc.getIsDeleted(), uc.getId()),
//                        (v1, v2) -> v1
//                ));
//        List<ClassesByCourseIdResponse> classesByCourseIdResponseList = classList.stream().map(c -> {
//            ClassesByCourseIdResponse response = new ClassesByCourseIdResponse();
//            response.setClassId(c.getId());
//            response.setCourseId(c.getCourse().getId());
//            response.setName(c.getName());
//            response.setAvailable(c.getAvailable());
//            response.setLocation(c.getLocation());
//            response.setPrice(c.getPrice());

//            List<ClassScheduleResponse> schedules = c.getClassSchedules().stream()
//                    .map(schedule -> new ClassScheduleResponse(
//                            schedule.getClassDate(),
//                            schedule.getStartTime().toString().substring(0, 5),
//                            schedule.getEndTime().toString().substring(0, 5)
//                    ))
//                    .collect(Collectors.toList());
//            response.setSchedules(schedules);
//
//            UserClassIsDeletedResponse userClassInfo = classIdToUserClassInfoMap.get(c.getId());
//            response.setUserClassId(Objects.nonNull(userClassInfo) ? userClassInfo.getUserClassId() : null);
//            response.setIsDeleted(Objects.nonNull(userClassInfo) ? userClassInfo.getIsDeleted() : null);
//            return response;
//        }).collect(Collectors.toList());
//
//        ResultResponse result = ResultResponse.success(classesByCourseIdResponseList);
//
//        try {
//            String resultString = objectMapper.writeValueAsString(result);
//            logger.info("Response: {}", resultString);
//        } catch (JsonProcessingException e) {
//            logger.error("Error serializing response", e);
//        }

//        return result;
        return null;
    }

    @Override
    public ResultResponse findByCourseId(Long courseId) {
        if (Objects.isNull(courseId)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: courseId cannot be empty");
        }
        List<ClassEntity> classEntities = classRepository.findByCourseId(courseId);
        List<ClassesByCourseIdResponse> classesByCourseIdResponseList = classEntities.stream().map(c -> {
            ClassesByCourseIdResponse response = new ClassesByCourseIdResponse();
            response.setClassId(c.getId());
            response.setCourseId(c.getCourse().getId());
            response.setName(c.getName());
            response.setAvailable(c.getAvailable());
            response.setLocation(c.getLocation());
            response.setPrice(c.getPrice());

            List<ClassScheduleResponse> schedules = c.getClassSchedules().stream()
                    .map(schedule -> new ClassScheduleResponse(
                            schedule.getClassDate(),
                            schedule.getStartTime().toString().substring(0, 5),
                            schedule.getEndTime().toString().substring(0, 5)
                    ))
                    .collect(Collectors.toList());
            response.setSchedules(schedules);

            response.setIsDeleted(c.getIsDeleted());
            response.setStatus(c.getStatus());
            return response;
        }).collect(Collectors.toList());
        return ResultResponse.success(classesByCourseIdResponseList);
    }

    @Override
    public ResultResponse delete(Long id) {
        Optional<ClassEntity> classEntityOptional = classRepository.findById(id);
        if (classEntityOptional.isPresent()) {
            ClassEntity classEntity = classEntityOptional.get();
            classEntity.setIsDeleted(true);
            classRepository.save(classEntity);
            return ResultResponse.success("Class deleted successfully");
        } else {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class not found.");
        }
    }

    @Override
    public ResultResponse findStatusList() {
        List<ClassStatus.StatusDTO> statuses = ClassStatus.getAllStatuses();
        return ResultResponse.success(statuses);
    }

    @Override
    public ResultResponse searchClasses(Integer status, Long courseId) {
        List<ClassEntity> classEntityList = null;
        if (status != null) {
            classEntityList = classRepository.findByStatusAndCourseId(ClassStatus.fromValue(status), courseId);
        }
        if (CollectionUtils.isEmpty(classEntityList)) {
            return ResultResponse.success(new ArrayList<>());
        }

        List<ClassesByTypeResponse> classResponses = classEntityList.stream()
                .map(this::convertToClassesByStatusResponse)
                .collect(Collectors.toList());

        return ResultResponse.success(classResponses);
    }

    @Override
    public ResultResponse save(ClassRequest classRequest) {
        if (Objects.isNull(classRequest)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: classRequest cannot be empty.");
        }
        if (Objects.isNull(classRequest.getAvailable()) || Objects.isNull(classRequest.getCourseId()) || Objects.isNull(classRequest.getPrice()) || StringUtils.isNullOrEmpty(classRequest.getLocation()) || StringUtils.isNullOrEmpty(classRequest.getName())) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: parameters error");
        }
        Optional<Course> courseOptional = courseRepository.findByIdAndIsDeletedFalse(classRequest.getCourseId());
        if (courseOptional.isEmpty()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: course not found");
        }

        ClassEntity classEntity = new ClassEntity();
        BeanUtils.copyProperties(classRequest, classEntity);
        classEntity.setCourse(courseOptional.get());
        classEntity.setStatus(ClassStatus.NOT_STARTED);
        classRepository.save(classEntity);

        ClassResponse classResponse = new ClassResponse();
        BeanUtils.copyProperties(classEntity, classResponse);
        classResponse.setCourseId(classEntity.getCourse().getId());
        classResponse.setClassStatus(classEntity.getStatus());
        return ResultResponse.success(classResponse);
    }

    @Override
    public ResultResponse edit(ClassEditRequest classEditRequest) {
        if (Objects.isNull(classEditRequest.getId())) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class id cannot be empty.");
        }
        if (Objects.isNull(classEditRequest.getLocation()) || Objects.isNull(classEditRequest.getPrice()) || Objects.isNull(classEditRequest.getName()) || Objects.isNull(classEditRequest.getAvailable()) || Objects.isNull(classEditRequest.getStatus())) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class parameters cannot be empty.");
        }
        Optional<ClassEntity> classEntityOptional = classRepository.findByIdAndIsDeletedFalse(classEditRequest.getId());
        if (classEntityOptional.isEmpty()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Class not found.");
        }

        ClassEntity classEntity = classEntityOptional.get();
        BeanUtils.copyProperties(classEditRequest, classEntity);
        classRepository.save(classEntity);
        return ResultResponse.success();
    }

    private ClassesByTypeResponse convertToClassesByStatusResponse(ClassEntity classEntity) {
        ClassesByTypeResponse response = new ClassesByTypeResponse();
        response.setId(classEntity.getId());
        response.setName(classEntity.getName());
        response.setLocation(classEntity.getLocation());
        response.setAvailable(classEntity.getAvailable());
        response.setPrice(classEntity.getPrice());
        response.setStatus(classEntity.getStatus());
        response.setIsDeleted(classEntity.getIsDeleted());
        return response;
    }
}
