package com.kidsai.app.repository;

import com.kidsai.app.models.RechargeHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RechargeRepository extends JpaRepository<RechargeHistory, Long> {

    @Query("SELECT r FROM RechargeHistory r WHERE r.user.id = :userId")
    List<RechargeHistory> findAllByUserId(@Param("userId") Long userId);
}
