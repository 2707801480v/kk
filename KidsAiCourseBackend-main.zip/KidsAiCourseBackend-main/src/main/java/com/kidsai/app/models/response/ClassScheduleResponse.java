package com.kidsai.app.models.response;

import lombok.*;

import java.time.DayOfWeek;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class ClassScheduleResponse {
    private LocalDate classDate;
    private String startTime;
    private String endTime;
//    private DayOfWeek dayOfWeek;
}
