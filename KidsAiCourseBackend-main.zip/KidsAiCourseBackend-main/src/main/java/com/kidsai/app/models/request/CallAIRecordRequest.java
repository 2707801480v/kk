package com.kidsai.app.models.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Getter
@Setter
@ToString
public class CallAIRecordRequest {
    private Long userId;

    @NotBlank
    @Size(max = 120)
    private String endpoint;

    @NotBlank
    @Size(max = 120)
    private String API;

    @NotBlank
    @Size(max = 120)
    private String prompt;
}
