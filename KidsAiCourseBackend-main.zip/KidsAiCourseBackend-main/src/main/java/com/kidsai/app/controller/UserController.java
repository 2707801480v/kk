package com.kidsai.app.controller;

import com.kidsai.app.models.User;
import com.kidsai.app.models.response.UserResponse;
import com.kidsai.app.repository.UserRepository;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("")
    public ResponseEntity<ResultResponse> getUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UsernameNotFoundException("User not found"));
        UserResponse userRes = new UserResponse();
        BeanUtils.copyProperties(user, userRes);

        return ResponseEntity
                .ok()
                .body(ResultResponse.success(userRes));
    }

    @GetMapping("/status")
    public ResponseEntity<ResultResponse> getUserStatus() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || authentication instanceof AnonymousAuthenticationToken) {
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.success(false));
        }

        String email = authentication.getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        return ResponseEntity
                .ok()
                .body(ResultResponse.success(user.isStatus()));
    }
}
