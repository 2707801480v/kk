package com.kidsai.app.controller;

import com.kidsai.app.models.User;
import com.kidsai.app.models.request.ChangePasswordRequest;
import com.kidsai.app.models.request.LoginRequest;
import com.kidsai.app.models.request.RegisterRequest;
import com.kidsai.app.models.request.ResetPasswordRequest;
import com.kidsai.app.models.response.LoginResponse;
import com.kidsai.app.models.response.UserResponse;
import com.kidsai.app.repository.UserRepository;
import com.kidsai.app.service.EmailService;
import com.kidsai.app.service.impl.UserDetailsImpl;
import com.kidsai.app.utils.RedisUtil;
import com.kidsai.app.utils.exceptions.ResultResponse;
import com.kidsai.app.utils.security.JwtUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    public static final String VERIFY = "verify:";

    public static final String YES = "yes";
    public static final String NO = "no";

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    UserRepository userRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private EmailService emailService;

    @PostMapping("/login")
    public ResponseEntity<ResultResponse> authenticateUser(@Validated @RequestBody LoginRequest loginRequest) {

        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());

        if (userOptional.isEmpty()) {
            return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.NOT_FOUND.value()), "Error: User not found!"));
        }

        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
        String sessionToken = redisUtil.generateSessionToken(userDetails.getEmail());

        User userInfo = userRepository.findById(userDetails.getId()).orElseThrow(() -> new RuntimeException("Error: User is not found"));
        // update user status
        User user = new User();
        BeanUtils.copyProperties(userDetails, user);
        BeanUtils.copyProperties(userInfo, user);
        user.setStatus(true);
        userRepository.save(user);

        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setToken(jwtCookie.toString());
        loginResponse.setSessionToken(sessionToken);
        BeanUtils.copyProperties(user, loginResponse);

        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                .body(ResultResponse.success(loginResponse));
    }

    @PostMapping("/register")
    public ResponseEntity<ResultResponse> registerUser(@Validated @RequestBody RegisterRequest registerRequest) {
        if (registerRequest.getEmail().isEmpty() || registerRequest.getEmail().isBlank()) {
            return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email cannot be empty!"));
        }
        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            return ResponseEntity
                    .badRequest()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email is already registered!"));
        }
        Map<Object, Object> map = redisUtil.getHashEntries(registerRequest.getUuid());
        if (!registerRequest.getEmail().equals(map.get("email"))) {
            return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email does not match uuid."));
        }
        // Verify whether email is verified
        Object val = redisUtil.get(VERIFY + registerRequest.getUuid());
        if (Objects.isNull(val) || NO.equals(val)) {
            return ResponseEntity
                    .badRequest()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email is not verified!"));
        }
        if (YES.equals(val)) {
            // Create new user's account
            User user = new User(registerRequest.getEmail(),
                    encoder.encode(registerRequest.getPassword()),
                    registerRequest.getUsername(),
                    registerRequest.getMobile(),
                    registerRequest.getRole()
            );
            userRepository.save(user);

            UserResponse userRes = new UserResponse();
            BeanUtils.copyProperties(user, userRes);

            return ResponseEntity
                    .ok()
                    .body(ResultResponse.success(userRes));
        } else {
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Unknown Error"));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<ResultResponse> logout() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        // clean current cookie & session
        ResponseCookie cookie = jwtUtils.getCleanJwtCookie();
        redisUtil.deleteSessionToken(userDetails.getEmail());
        // update user status
        User user = new User();
        BeanUtils.copyProperties(userDetails, user);
        user.setStatus(false);
        User userInfo = userRepository.findById(userDetails.getId()).orElseThrow(() -> new RuntimeException("Error: User is not found"));
        BeanUtils.copyProperties(userInfo, user);
        userRepository.save(user);
        return ResponseEntity
                .ok()
                .header(HttpHeaders.SET_COOKIE, cookie.toString())
                .body(ResultResponse.success("You've been logged out!"));
    }

    @PostMapping("/changePassword")
    public ResponseEntity<ResultResponse> changePassword(@Validated @RequestBody ChangePasswordRequest changePasswordRequest) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        // verify whether old password is correct
        if (!encoder.matches(changePasswordRequest.getOldPwd(), userDetails.getPassword())) {
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Old password is incorrect"));
        }

        // verify whether new password and confirm password are same
        if (!changePasswordRequest.getNewPwd().equals(changePasswordRequest.getConfirmPwd())) {
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: New password and confirm password do not match"));
        }

        // update user password & status
        User user = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("Error: User is not found"));
        user.setPassword(encoder.encode(changePasswordRequest.getNewPwd()));
        user.setStatus(false);
        userRepository.save(user);
        // clean current cookie & session
        ResponseCookie cookie = jwtUtils.getCleanJwtCookie();
        redisUtil.deleteSessionToken(user.getEmail());
        return ResponseEntity
                .ok()
                .header(HttpHeaders.SET_COOKIE, cookie.toString())
                .body(ResultResponse.success("Password changed successfully, please login again."));
    }

    @PostMapping("/forgotPassword")
    public ResponseEntity<ResultResponse> forgotPassword(@RequestParam @NotBlank String email) {
        if (email.isEmpty() || email.isBlank()) {
            return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email cannot be empty!"));
        }
        ResultResponse checkedMailResponse = emailService.checkMail(email);
        if (checkedMailResponse.getCode().equals(String.valueOf(HttpStatus.OK.value())) && checkedMailResponse.getResult() == Boolean.FALSE) {
            return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Invalid email format!"));
        }
        boolean userPresent = userRepository.findByEmail(email).isPresent();
        if (!userPresent) {
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email does not exist"));
        }
        ResultResponse resultResponse = emailService.sendEmail(email);
        if (resultResponse != null && resultResponse.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            // return uuid
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.success(resultResponse.getResult().toString()));
        }
        return ResponseEntity
                .ok()
                .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST), "Send email is fail, please retry"));
    }

    @PostMapping("/resetPassword")
    public ResponseEntity<ResultResponse> resetPassword(@RequestBody ResetPasswordRequest request) {
        ResponseEntity<ResultResponse> validationResponse = validateRequest(request);
        if (validationResponse != null) {
            return validationResponse;
        }
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            return ResponseEntity
                    .ok()
                    .body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST), "Error: New password and confirm password do not match"));
        }
        Map<Object, Object> map = redisUtil.getHashEntries(request.getUuid());
        if (map == null || !request.getEmail().equals(map.get("email")) || !request.getValidCode().equals(map.get("code"))) {
            return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Invalid request"));
        }

        Optional<User> userOptional = userRepository.findByEmail(request.getEmail());
        userOptional.ifPresent(user -> {
            user.setPassword(encoder.encode(request.getNewPassword()));
            userRepository.save(user);
        });
        redisUtil.pop(request.getUuid());
        return ResponseEntity.ok()
                .body(ResultResponse.success("Password set successfully"));
    }

    private ResponseEntity<ResultResponse> validateRequest(ResetPasswordRequest request) {
        if (request.getEmail().isBlank() || request.getEmail().isEmpty()) {
            return createErrorResponse("Error: Email cannot be empty!");
        }
        if (request.getNewPassword().isBlank() || request.getNewPassword().isEmpty()) {
            return createErrorResponse("Error: New password cannot be empty!");
        }
        if (request.getConfirmPassword().isBlank() || request.getConfirmPassword().isEmpty()) {
            return createErrorResponse("Error: Confirm password cannot be empty!");
        }
        if (request.getUuid().isBlank() || request.getUuid().isEmpty()) {
            return createErrorResponse("Error: Uuid cannot be empty!");
        }
        if (request.getValidCode().isBlank() || request.getValidCode().isEmpty()) {
            return createErrorResponse("Error: Valid code cannot be empty!");
        }
        return null;
    }

    private ResponseEntity<ResultResponse> createErrorResponse(String message) {
        return ResponseEntity.ok().body(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), message));
    }
}
