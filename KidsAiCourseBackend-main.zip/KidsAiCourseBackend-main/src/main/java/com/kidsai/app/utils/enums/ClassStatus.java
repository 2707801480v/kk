package com.kidsai.app.utils.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum ClassStatus {
    NOT_STARTED(0, "Not started"),
    IN_PROGRESS(1, "In progress"),
    COMPLETED(2, "Completed");

    private final int code;
    private final String description;

    ClassStatus(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static ClassStatus fromValue(int value) {
        for (ClassStatus status : values()) {
            if (status.code == value) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid ClassStatus value: " + value);
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static ClassStatus getByCode(int code) {
        return Arrays.stream(ClassStatus.values())
                .filter(status -> status.getCode() == code)
                .findFirst()
                .orElse(null);
    }

    public static boolean isValidCode(int code) {
        return Arrays.stream(ClassStatus.values())
                .anyMatch(status -> status.getCode() == code);
    }

    public static String getAllStatusDescriptions() {
        return Arrays.stream(ClassStatus.values())
                .map(status -> status.getCode() + ": " + status.getDescription())
                .reduce((s1, s2) -> s1 + ", " + s2)
                .orElse("");
    }

    public static class StatusDTO {
        private int code;
        private String name;
        private String description;

        public StatusDTO(ClassStatus status) {
            this.code = status.getCode();
            this.name = status.name();
            this.description = status.getDescription();
        }

        // Getters
        public int getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }
    }

    public static List<StatusDTO> getAllStatuses() {
        return Arrays.stream(ClassStatus.values())
                .map(StatusDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return this.name() + "(" + this.code + ", " + this.description + ")";
    }
}