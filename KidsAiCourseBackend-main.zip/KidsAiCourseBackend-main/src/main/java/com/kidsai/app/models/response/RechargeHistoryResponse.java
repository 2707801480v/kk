package com.kidsai.app.models.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RechargeHistoryResponse {
    private Long id;
    private Long userId;
    private BigDecimal rechargeAmount;
    private String rechargeDate;
}
