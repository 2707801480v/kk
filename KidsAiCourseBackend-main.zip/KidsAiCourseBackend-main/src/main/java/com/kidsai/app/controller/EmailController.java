package com.kidsai.app.controller;

import com.kidsai.app.service.EmailService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @PostMapping(value = "/send")
    public ResponseEntity<ResultResponse> sendEmail(@RequestParam String email) {
        ResultResponse result = emailService.sendEmail(email);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PostMapping(value = "/check")
    public ResponseEntity<ResultResponse> checkMail(@RequestParam String email) {
        ResultResponse resultResponse = emailService.checkMail(email);
        if (resultResponse.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(resultResponse);
        }
        return ResponseEntity.badRequest().body(resultResponse);
    }

    @PostMapping(value = "/valid")
    public ResponseEntity<ResultResponse> validMail(@RequestParam String code, String uuid) {
        ResultResponse resultResponse = emailService.validMail(code, uuid);
        if (resultResponse.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(resultResponse);
        }
        return ResponseEntity.badRequest().body(resultResponse);
    }
}
