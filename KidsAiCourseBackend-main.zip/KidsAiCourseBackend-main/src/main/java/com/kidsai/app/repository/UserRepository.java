package com.kidsai.app.repository;

import com.kidsai.app.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    Boolean existsByEmail(String email);

    @Modifying
    @Query("UPDATE User u SET u.balance = u.balance + :rechargeAmount WHERE u.id = :userId")
    int recharge(@Param("userId") Long userId, @Param("rechargeAmount") BigDecimal rechargeAmount);

}
