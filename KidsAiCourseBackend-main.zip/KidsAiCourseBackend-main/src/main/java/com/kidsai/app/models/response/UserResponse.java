package com.kidsai.app.models.response;

import com.kidsai.app.utils.enums.Role;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;


@Getter
@Setter
@NoArgsConstructor
@ToString
public class UserResponse {
    private Long id;
    private String email;
    private String username;
    private BigDecimal balance;
    private Role role;
    private String mobile;
}
