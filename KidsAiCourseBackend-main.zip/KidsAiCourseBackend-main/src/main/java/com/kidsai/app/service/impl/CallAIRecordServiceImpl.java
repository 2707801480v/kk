package com.kidsai.app.service.impl;

import com.kidsai.app.models.CallAIRecord;
import com.kidsai.app.models.request.CallAIRecordRequest;
import com.kidsai.app.repository.CallAIRecordRepository;
import com.kidsai.app.service.CallAIRecordService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class CallAIRecordServiceImpl implements CallAIRecordService {

    @Autowired
    private CallAIRecordRepository callAIRecordRepository;

    @Override
    public ResultResponse save(CallAIRecordRequest callAIRecordRequest) {

        if (callAIRecordRequest.getAPI().isEmpty() || callAIRecordRequest.getAPI().isBlank()) {
            return ResultResponse.error("Error: API cannot be empty");
        }
        if (callAIRecordRequest.getEndpoint().isEmpty() || callAIRecordRequest.getEndpoint().isBlank()) {
            return ResultResponse.error("Error: Endpoint cannot be empty");
        }
        if (Objects.isNull(callAIRecordRequest.getUserId())) {
            return ResultResponse.error("Error: UserID cannot be empty");
        }
        CallAIRecord callAIRecord = new CallAIRecord();
        BeanUtils.copyProperties(callAIRecordRequest, callAIRecord);
        callAIRecordRepository.save(callAIRecord);
        return ResultResponse.success();
    }
}
