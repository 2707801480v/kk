package com.kidsai.app.service;

import com.kidsai.app.models.CallAIRecord;
import com.kidsai.app.models.request.CallAIRecordRequest;
import com.kidsai.app.utils.exceptions.ResultResponse;

public interface CallAIRecordService {

    ResultResponse save(CallAIRecordRequest callAIRecordRequest);
}
