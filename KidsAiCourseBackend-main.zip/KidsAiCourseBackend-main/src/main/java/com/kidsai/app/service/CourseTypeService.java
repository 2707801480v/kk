package com.kidsai.app.service;

import com.kidsai.app.models.request.CourseTypeRequest;
import com.kidsai.app.utils.exceptions.ResultResponse;

public interface CourseTypeService {

    ResultResponse getList();

    ResultResponse save(CourseTypeRequest courseTypeRequest);

    ResultResponse edit(CourseTypeRequest courseTypeRequest);

    ResultResponse delete(Long id);

    ResultResponse findByName(String name);
}
