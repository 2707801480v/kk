package com.kidsai.app.controller;

import com.kidsai.app.models.CourseType;
import com.kidsai.app.models.request.CourseTypeRequest;
import com.kidsai.app.service.CourseTypeService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.Optional;

@RestController
@RequestMapping("/courseType")
public class CourseTypeController {

    @Autowired
    private CourseTypeService courseTypeService;

    @GetMapping("/getList")
    public ResponseEntity<ResultResponse> getList() {
        ResultResponse result = courseTypeService.getList();
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@RequestBody CourseTypeRequest courseTypeRequest) {
        ResultResponse result = courseTypeService.save(courseTypeRequest);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @PutMapping("/edit")
    public ResponseEntity<ResultResponse> edit(@RequestBody CourseTypeRequest courseTypeRequest) {
        ResultResponse result = courseTypeService.edit(courseTypeRequest);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<ResultResponse> delete(@RequestParam @NotBlank Long id) {
        ResultResponse result = courseTypeService.delete(id);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/findByName")
    public ResponseEntity<ResultResponse> findByName(@RequestParam @NotBlank String name) {
        ResultResponse response = courseTypeService.findByName(name);
        if (response.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().body(response);
    }
}
