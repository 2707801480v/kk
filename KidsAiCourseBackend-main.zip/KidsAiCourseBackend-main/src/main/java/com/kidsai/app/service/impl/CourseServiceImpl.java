package com.kidsai.app.service.impl;

import com.kidsai.app.models.ClassEntity;
import com.kidsai.app.models.Course;
import com.kidsai.app.models.CourseType;
import com.kidsai.app.models.request.CourseRequest;
import com.kidsai.app.models.response.CoursesByNameResponse;
import com.kidsai.app.models.response.CoursesByTypeResponse;
import com.kidsai.app.repository.ClassRepository;
import com.kidsai.app.repository.CourseRepository;
import com.kidsai.app.repository.CourseTypeRepository;
import com.kidsai.app.service.CourseService;
import com.kidsai.app.utils.enums.CourseStatus;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private CourseTypeRepository courseTypeRepository;

    @Autowired
    private ClassRepository classRepository;

    @Override
    public ResultResponse findCoursesByType(Long courseTypeId) {
        Optional<List<Course>> coursesByTypeOptional = courseRepository.findCoursesByType(courseTypeId);
        if (coursesByTypeOptional.isEmpty()) {
            return ResultResponse.success("No courses found for the given course type ID");
        }
        List<CoursesByTypeResponse> coursesByTypeResponses = coursesByTypeOptional.get().stream().map(course -> {
            CoursesByTypeResponse response = new CoursesByTypeResponse();
            response.setId(course.getId());
            response.setName(course.getName());
            response.setCourseTypeId(course.getCourseType().getId());
            response.setCourseTypeName(course.getCourseType().getName());
            response.setDescription(course.getDescription());
            response.setPrice(course.getPrice());
            List<ClassEntity> classEntityList = classRepository.findByCourseId(course.getId());
            response.setNumOfLessons(classEntityList.size());
            response.setStatus(course.getStatus());
            return response;
        }).toList();
        return ResultResponse.success(coursesByTypeResponses);
    }

    @Override
    public ResultResponse save(CourseRequest courseRequest) {
        if (courseRequest.getName().isBlank() || courseRequest.getName().isEmpty()) {
            return ResultResponse.error("Error: Course name cannot be empty.");
        }

        if (courseRequest.getCourseTypeId() == null) {
            return ResultResponse.error("Error: CourseTypeId cannot be empty.");
        }

        Optional<Course> courseOptional = courseRepository.findByName(courseRequest.getName());
        if (courseOptional.isPresent()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Course already exists.");
        }
        Course course = new Course();
        BeanUtils.copyProperties(courseRequest, course);

        CourseType courseType = new CourseType();
        courseType.setId(courseRequest.getCourseTypeId());
        course.setCourseType(courseType);
        course.setStatus(CourseStatus.UNPUBLISHED);
        course.setIsDeleted(false);
        courseRepository.save(course);
        return ResultResponse.success();
    }

    @Override
    public ResultResponse findCoursesByName(String name) {
        Optional<List<Course>> fuzzyByNameOptional = courseRepository.findFuzzyByName(name);
        if (fuzzyByNameOptional.isEmpty()) {
            return ResultResponse.success("No courses found for the given course name");
        }
        List<CoursesByNameResponse> coursesByNameResponseList = fuzzyByNameOptional.get().stream().map(course -> {
            CoursesByNameResponse response = new CoursesByNameResponse();
            response.setId(course.getId());
            response.setName(course.getName());
            response.setCourseTypeId(course.getCourseType().getId());
            response.setCourseTypeName(course.getCourseType().getName());
            response.setDescription(course.getDescription());
            response.setPrice(course.getPrice());
            List<ClassEntity> classEntityList = classRepository.findByCourseId(course.getId());
            response.setNumOfLessons(classEntityList.size());
            response.setStatus(course.getStatus());
            return response;
        }).toList();
        return ResultResponse.success(coursesByNameResponseList);

    }

    @Override
    public ResultResponse findAll() {
        List<Course> courseList = courseRepository.findAll();
        if (courseList.isEmpty()) {
            return ResultResponse.success("No courses found.");
        }
        List<CoursesByTypeResponse> coursesByTypeResponses = courseList.stream().map(course -> {
            CoursesByTypeResponse response = new CoursesByTypeResponse();
            response.setId(course.getId());
            response.setName(course.getName());
            response.setCourseTypeId(course.getCourseType().getId());
            response.setCourseTypeName(course.getCourseType().getName());
            response.setDescription(course.getDescription());
            response.setPrice(course.getPrice());
            List<ClassEntity> classEntityList = classRepository.findByCourseId(course.getId());
            response.setNumOfLessons(classEntityList.size());
            response.setStatus(course.getStatus());
            return response;
        }).toList();
        return ResultResponse.success(coursesByTypeResponses);
    }

    @Override
    public ResultResponse findStatusList() {
        List<CourseStatus.StatusDTO> statuses = CourseStatus.getAllStatuses();
        return ResultResponse.success(statuses);
    }

    @Override
    public ResultResponse saveStatus(Long courseId, Integer status) {
        if (Objects.isNull(courseId)) {
            return ResultResponse.error("Error: Course Id cannot be empty.");
        }
        Optional<Course> courseOptional = courseRepository.findById(courseId);
        if (courseOptional.isEmpty()) {
            return ResultResponse.error("Error: Course is not found.");
        }
        Course course = courseOptional.get();
        CourseStatus courseStatus = CourseStatus.fromValue(status);
        course.setStatus(courseStatus);

        courseRepository.save(course);
        return ResultResponse.success();
    }

    @Override
    public ResultResponse delete(Long id) {
        Optional<Course> courseOptional = courseRepository.findById(id);
        if (courseOptional.isPresent()) {
            Course course = courseOptional.get();
            course.setIsDeleted(true);
            courseRepository.save(course);
            return ResultResponse.success("Course deleted successfully");
        } else {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Course not found.");
        }
    }

    @Transactional
    @Override
    public ResultResponse editCourse(Long id, CourseRequest courseRequest) {
        Optional<Course> existingCourse = courseRepository.findById(id);
        if (existingCourse.isEmpty()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Course not found.");
        }

        Course course = existingCourse.get();
        if (course.getStatus() == CourseStatus.PUBLISHED) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Cannot edit a published course.");
        }

        course.setName(courseRequest.getName());
        course.setDescription(courseRequest.getDescription());
        course.setPrice(courseRequest.getPrice());
        Optional<CourseType> courseTypeOptional = courseTypeRepository.findById(courseRequest.getCourseTypeId());
        course.setCourseType(courseTypeOptional.orElse(null));
        course = courseRepository.save(course);
        List<ClassEntity> classEntityList = classRepository.findByCourseId(id);
        CoursesByNameResponse response = convertToDTO(course);
        response.setNumOfLessons(classEntityList.size());
        return ResultResponse.success(response);
    }

    @Override
    public ResultResponse searchCourses(Long courseTypeId, Integer status) {
        List<Course> courses;

        if (courseTypeId != null && status != null) {
            courses = courseRepository.findByCourseTypeIdAndStatus(courseTypeId, CourseStatus.fromValue(status));
        } else if (courseTypeId != null) {
            courses = courseRepository.findByCourseTypeId(courseTypeId);
        } else if (status != null) {
            courses = courseRepository.findByStatus(CourseStatus.fromValue(status));
        } else {
            courses = courseRepository.findAll();
        }

        if (courses.isEmpty()) {
            return ResultResponse.success("No courses found matching the criteria.");
        }

        List<CoursesByTypeResponse> courseResponses = courses.stream()
                .map(this::convertToCoursesByTypeResponse)
                .collect(Collectors.toList());

        return ResultResponse.success(courseResponses);
    }

    @Override
    public ResultResponse findById(Long id) {
        if (Objects.isNull(id)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Course id cannot be empty.");
        }
        Optional<Course> courseOptional = courseRepository.findByIdAndIsDeletedFalse(id);
        if (courseOptional.isEmpty()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Course not found.");
        }
        CoursesByTypeResponse response = convertToCoursesByTypeResponse(courseOptional.get());
        return ResultResponse.success(response);
    }

    private CoursesByTypeResponse convertToCoursesByTypeResponse(Course course) {
        CoursesByTypeResponse response = new CoursesByTypeResponse();
        response.setId(course.getId());
        response.setName(course.getName());
        response.setCourseTypeId(course.getCourseType().getId());
        response.setCourseTypeName(course.getCourseType().getName());
        response.setDescription(course.getDescription());
        response.setPrice(course.getPrice());
        List<ClassEntity> classEntityList = classRepository.findByCourseId(course.getId());
        response.setNumOfLessons(classEntityList.size());
        response.setStatus(course.getStatus());
        return response;
    }

    private CoursesByNameResponse convertToDTO(Course course) {
        CoursesByNameResponse dto = new CoursesByNameResponse();
        dto.setId(course.getId());
        dto.setName(course.getName());
        dto.setDescription(course.getDescription());
        dto.setPrice(course.getPrice());
        dto.setCourseTypeName(course.getCourseType().getName());
        dto.setStatus(CourseStatus.valueOf(course.getStatus().name()));
        return dto;
    }
}
