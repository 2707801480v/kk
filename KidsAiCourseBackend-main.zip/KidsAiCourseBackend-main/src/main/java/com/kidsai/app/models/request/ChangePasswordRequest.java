package com.kidsai.app.models.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ChangePasswordRequest {

    @NotBlank
    @Size(max = 120)
    private String oldPwd;

    @NotBlank
    @Size(max = 120)
    private String newPwd;

    @NotBlank
    @Size(max = 120)
    private String confirmPwd;
}
