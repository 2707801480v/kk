package com.kidsai.app.repository;

import com.kidsai.app.models.ClassEntity;
import com.kidsai.app.utils.enums.ClassStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ClassRepository extends JpaRepository<ClassEntity, Long> {

//    @Query("SELECT c FROM ClassEntity c " +
//            "WHERE c.course.id = :courseId " +
//            "AND c.startDate <= :startDate " +
//            "AND c.endDate >= :endDate")
//    List<ClassEntity> findByCourseIdAndDateRange(@Param("courseId") Long courseId,
//                                                 @Param("startDate") LocalDate startDate,
//                                                 @Param("endDate") LocalDate endDate);

    @Query("SELECT c FROM ClassEntity c " +
            "WHERE c.course.id = :courseId " +
            "AND c.isDeleted = false")
    List<ClassEntity> findByCourseId(@Param("courseId") Long courseId);

    List<ClassEntity> findByStatusAndCourseId(@Param("status") ClassStatus status, @Param("courseId") Long courseId);

    Optional<ClassEntity> findByIdAndIsDeletedFalse(Long id);

}
