package com.kidsai.app.service.impl;

import com.kidsai.app.models.RechargeHistory;
import com.kidsai.app.models.User;
import com.kidsai.app.models.response.RechargeHistoryResponse;
import com.kidsai.app.models.response.UserRechargeResponse;
import com.kidsai.app.repository.RechargeRepository;
import com.kidsai.app.repository.UserRepository;
import com.kidsai.app.service.RechargeHistoryService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RechargeHistoryServiceImpl implements RechargeHistoryService {

    @Autowired
    private RechargeRepository rechargeRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public ResultResponse save(Long userId, BigDecimal rechargeAmount) {
        if (Objects.isNull(userId)) {
            return ResultResponse.error("Error: userId cannot be empty.");
        }
        if (Objects.isNull(rechargeAmount)) {
            return ResultResponse.error("Error: rechargeAmount cannot be empty.");
        }

        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            return ResultResponse.error("Error: cannot found this user.");
        }

        int flag = userRepository.recharge(userId, rechargeAmount);

        RechargeHistory rechargeHistory = new RechargeHistory();
        User user = new User();
        user.setId(userId);
        rechargeHistory.setUser(user);
        rechargeHistory.setRechargeAmount(rechargeAmount);
        rechargeRepository.save(rechargeHistory);

        if (flag > 0) {
            UserRechargeResponse userRechargeResponse = new UserRechargeResponse();
            userRechargeResponse.setUserId(userId);
            userRechargeResponse.setBalance(userOptional.get().getBalance().add(rechargeAmount));
            return ResultResponse.success(userRechargeResponse);
        }
        return ResultResponse.error("Error: Recharge failed.");
    }

    @Override
    public ResultResponse findAllByUserId(Long userId) {
        if (Objects.isNull(userId)) {
            return ResultResponse.error("Error: userId cannot be empty.");
        }
        List<RechargeHistory> rechargeHistoryList = rechargeRepository.findAllByUserId(userId);
        if (!rechargeHistoryList.isEmpty()) {
            rechargeHistoryList.sort(Comparator.comparing(RechargeHistory::getId).reversed());
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            List<RechargeHistoryResponse> responseList = rechargeHistoryList.stream().map(r -> {
                RechargeHistoryResponse response = new RechargeHistoryResponse();
                response.setId(r.getId());
                response.setUserId(r.getUser().getId());
                response.setRechargeAmount(r.getRechargeAmount());
                response.setRechargeDate(Objects.isNull(r.getGmtCreate()) ? null : dateFormat.format(r.getGmtCreate()));
                return response;
            }).collect(Collectors.toList());
            return ResultResponse.success(responseList);
        }
        return ResultResponse.success(rechargeHistoryList);
    }
}
