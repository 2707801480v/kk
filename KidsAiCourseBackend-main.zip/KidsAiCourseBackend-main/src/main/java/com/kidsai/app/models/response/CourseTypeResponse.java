package com.kidsai.app.models.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class CourseTypeResponse {
    private Long id;
    private String name;
    private String description;
}
