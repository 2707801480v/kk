package com.kidsai.app.service;

import com.kidsai.app.utils.exceptions.ResultResponse;

import java.time.LocalDate;

public interface UserClassService {

    ResultResponse save(Long userId, Long classId, Boolean isDelete);

    ResultResponse getTotalClassInfo(Long userId);

    ResultResponse getUserCoursesByUserId(Long userId);

    ResultResponse getUserClassesByUserIdAndDate(Long userId, LocalDate startDate, LocalDate endDate);
}
