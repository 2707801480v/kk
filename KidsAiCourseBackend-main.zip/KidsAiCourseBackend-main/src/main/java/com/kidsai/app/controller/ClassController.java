package com.kidsai.app.controller;

import com.kidsai.app.models.request.ClassEditRequest;
import com.kidsai.app.models.request.ClassRequest;
import com.kidsai.app.service.ClassService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@RestController
@RequestMapping("/class")
public class ClassController {

    @Autowired
    private ClassService classService;

    @GetMapping("/findByCourseIdAndUserId")
    public ResponseEntity<ResultResponse> findByCourseIdAndUserId(@NotBlank @RequestParam Long courseId,
                                                                  @RequestParam Long userId,
                                                                  @RequestParam String startDate,
                                                                  @RequestParam String endDate) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate parsedStartDate = LocalDate.parse(startDate, formatter);
            LocalDate parsedEndDate = LocalDate.parse(endDate, formatter);

            ResultResponse result = classService.findByCourseIdAndDateRange(courseId, userId, parsedStartDate, parsedEndDate);

            if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
                return ResponseEntity.ok(result);
            }
            return ResponseEntity.badRequest().body(result);
        } catch (DateTimeParseException e) {
            return ResponseEntity.badRequest().body(ResultResponse.error(
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    "Invalid date format. Use dd/MM/yyyy"
            ));
        }
    }

    @GetMapping("/findByCourseId")
    public ResponseEntity<ResultResponse> findByCourseIdAndUserId(@RequestParam Long courseId) {
        ResultResponse result = classService.findByCourseId(courseId);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<ResultResponse> delete(@RequestParam Long id) {
        ResultResponse result = classService.delete(id);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/findClassStatus")
    public ResponseEntity<ResultResponse> findStatusList() {
        ResultResponse result = classService.findStatusList();
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/search")
    public ResponseEntity<ResultResponse> searchClasses(@RequestParam("status") Integer status, @RequestParam("courseId") Long courseId) {
        ResultResponse response = classService.searchClasses(status, courseId);
        if (response.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@RequestBody ClassRequest classRequest) {
        ResultResponse response = classService.save(classRequest);
        if (response.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().body(response);
    }

    @PutMapping("/edit")
    public ResponseEntity<ResultResponse> edit(@RequestBody ClassEditRequest classRequest) {
        ResultResponse response = classService.edit(classRequest);
        if (response.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.badRequest().body(response);
    }
}

