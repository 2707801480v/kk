package com.kidsai.app.service;

import com.kidsai.app.models.request.ClassEditRequest;
import com.kidsai.app.models.request.ClassRequest;
import com.kidsai.app.utils.exceptions.ResultResponse;

import java.time.LocalDate;

public interface ClassService {

    ResultResponse findByCourseIdAndDateRange(Long courseId, Long userId, LocalDate startDate, LocalDate endDate);

    ResultResponse findByCourseId(Long courseId);

    ResultResponse delete(Long id);

    ResultResponse findStatusList();

    ResultResponse searchClasses(Integer status, Long courseId);

    ResultResponse save(ClassRequest classRequest);
    ResultResponse edit(ClassEditRequest classEditRequest);
}
