package com.kidsai.app.repository;

import com.kidsai.app.models.ClassEntity;
import com.kidsai.app.models.UserClass;
import com.kidsai.app.models.response.UserCourseResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface UserClassRepository extends JpaRepository<UserClass, Long> {

    @Query("SELECT COUNT(uc) FROM UserClass uc WHERE uc.user.id= :userId AND uc.isDeleted = false")
    Integer countTotalClassesByUserId(@Param("userId") Long userId);


    @Query("SELECT COUNT(uc) FROM UserClass uc WHERE uc.user.id = :userId AND uc.isCompleted = true AND uc.isDeleted = false")
    Integer countCompletedClassesByUserId(@Param("userId") Long userId);

    @Query("SELECT new com.kidsai.app.models.response.UserCourseResponse(" +
            "cls.course.courseType.name, cls.course.name, cls.name, cls.price, cls.status, uc.gmtCreate) " +
            "FROM ClassEntity cls " +
            "JOIN cls.course c " +
            "JOIN c.courseType ct " +
            "JOIN cls.userClassSet uc " +
            "WHERE uc.user.id = :userId " +
            "AND uc.isDeleted = false")
    List<UserCourseResponse> getUserCourseAndClassInfo(@Param("userId") Long userId);

//    @Query("SELECT c " +
//            "FROM ClassEntity c " +
//            "INNER JOIN c.userClassSet uc " +
//            "WHERE uc.user.id = :userId " +
//            "AND uc.isDeleted = false " +
//            "AND c.startDate <= :endDate " +
//            "AND c.endDate >= :startDate")
//    List<ClassEntity> getUserClassesByUserIdAndDate(@Param("userId") Long userId,
//                                                    @Param("startDate") LocalDate startDate,
//                                                    @Param("endDate") LocalDate endDate);

    @Query("SELECT uc FROM UserClass uc WHERE uc.user.id = :userId AND uc.classEntity.id = :classId")
    List<UserClass> findByUserIdAndClassId(@Param("userId") Long userId, @Param("classId") Long classId);

    @Query("SELECT uc FROM UserClass uc " +
            "WHERE uc.user.id = :userId " +
            "AND uc.classEntity IN :classList")
    List<UserClass> findByUserIdAndClassEntityIn(@Param("userId") Long userId, @Param("classList") List<ClassEntity> classList);
}
