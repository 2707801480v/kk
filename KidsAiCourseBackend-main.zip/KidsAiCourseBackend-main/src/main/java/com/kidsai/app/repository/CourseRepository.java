package com.kidsai.app.repository;

import com.kidsai.app.models.Course;
import com.kidsai.app.utils.enums.CourseStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {


    @Query("SELECT c FROM Course c WHERE c.courseType.id = :courseTypeId")
    Optional<List<Course>> findCoursesByType(@Param("courseTypeId") Long courseTypeId);

    Optional<Course> findByName(String name);

    @Query("SELECT c FROM Course c WHERE c.name LIKE %:name%")
    Optional<List<Course>> findFuzzyByName(@Param("name") String name);

    List<Course> findByCourseTypeIdAndStatus(@Param("courseTypeId") Long courseTypeId, @Param("status") CourseStatus status);

    List<Course> findByCourseTypeId(@Param("courseTypeId") Long courseTypeId);

    List<Course> findByStatus(@Param("status") CourseStatus status);

    Optional<Course> findByIdAndIsDeletedFalse(Long id);
}
