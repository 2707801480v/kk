package com.kidsai.app.controller;

import com.kidsai.app.service.UserClassService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@RestController
@RequestMapping("/userClass")
public class UserClassController {

    @Autowired
    private UserClassService userClassService;

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@NotBlank @RequestParam Long userId, @RequestParam Long classId, @RequestParam Boolean isDelete) {
        ResultResponse result = userClassService.save(userId, classId, isDelete);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/getTotalInfo")
    public ResponseEntity<ResultResponse> getTotalClassInfo(@NotBlank @RequestParam Long userId) {
        ResultResponse result = userClassService.getTotalClassInfo(userId);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/getUserCourses")
    public ResponseEntity<ResultResponse> getUserCoursesByUserId(@NotBlank @RequestParam Long userId) {
        ResultResponse result = userClassService.getUserCoursesByUserId(userId);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }

    @GetMapping("/getUserClasses")
    public ResponseEntity<ResultResponse> getUserClassesByUserIdAndDate(@NotBlank @RequestParam Long userId, @RequestParam String startDate, @RequestParam String endDate) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate parsedStartDate = LocalDate.parse(startDate, formatter);
            LocalDate parsedEndDate = LocalDate.parse(endDate, formatter);
            ResultResponse result = userClassService.getUserClassesByUserIdAndDate(userId, parsedStartDate, parsedEndDate);
            if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
                return ResponseEntity.ok(result);
            }
            return ResponseEntity.badRequest().body(result);
        } catch (DateTimeParseException e) {
            return ResponseEntity.badRequest().body(ResultResponse.error(
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    "Invalid date format. Use dd/MM/yyyy"
            ));
        }
    }
}
