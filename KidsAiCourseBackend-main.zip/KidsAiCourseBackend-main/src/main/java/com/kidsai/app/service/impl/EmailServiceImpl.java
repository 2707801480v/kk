package com.kidsai.app.service.impl;

import com.kidsai.app.repository.UserRepository;
import com.kidsai.app.service.EmailService;
import com.kidsai.app.utils.RedisUtil;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class EmailServiceImpl implements EmailService {
    private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    public static final Integer EXPIRE_TIME_THIRTY = 30;
    public static final Integer EXPIRE_TIME_SIXTY = 60;

    public static final String YES = "yes";
    public static final String NO = "no";

    public static final String CODE = "code";
    public static final String EMAIL = "email";

    public static final String VERIFY = "verify:";
    public static final String EMAIL_TIMER = "emailTimer:";

    public static final String EXISTS = "exists";

    private static final String SMTP_HOST = "smtp.163.com";
    private static final String SMTP_PORT = "465";

    public static final String EMAIL_FROM = "18803360392@163.com";

    // 授权码,有效期180天
    public static final String EMAIL_PASSWORD = "AHRUTPRRNFLQADXU";

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private UserRepository userRepository;

    @Override
    public ResultResponse sendEmail(String to) {

        // Limit call frequency 1 email per minute
        String timeKey = EMAIL_TIMER + to;
        long timeLeft = redisUtil.getTime(timeKey);
        if (timeLeft > 0) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Request too frequently. Please wait for a while.");
        }

        Random random = new Random();
        int randomNumber = random.nextInt(999999);
        String formattedNumber = String.format("%06d", randomNumber);
        Authenticator authenticator = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
            }
        };
        Session mailSession = Session.getInstance(getProperties(), authenticator);
        MimeMessage message = new MimeMessage(mailSession) {
        };

        try {
            InternetAddress from = new InternetAddress(EMAIL_FROM, "Cryptosphere");
            message.setFrom(from);
            InternetAddress toAddress = new InternetAddress(to);
            message.setRecipient(MimeMessage.RecipientType.TO, toAddress);

            message.setSubject("Cryptosphere app email verification code.");
            message.setHeader("Content-Transfer-Encoding", "base64");
            message.setContent(formattedNumber, "text/html;charset=UTF-8");
            Transport.send(message);

            UUID uuid = UUID.randomUUID();
            Map<String, String> map = new HashMap<>();
            map.put(CODE, formattedNumber);
            map.put(EMAIL, to);

            redisUtil.add(uuid.toString(), map, EXPIRE_TIME_SIXTY * 100, TimeUnit.SECONDS);
            redisUtil.set(timeKey, EXISTS, EXPIRE_TIME_SIXTY, TimeUnit.SECONDS);

            logger.info("sendEmail method: requestBody:{} ", message);
            logger.info("sendEmail method: redis set key:{}, value:{} ,expireTime:{}", uuid, formattedNumber, EXPIRE_TIME_SIXTY);

            return ResultResponse.success(uuid);
        } catch (UnsupportedEncodingException | MessagingException e) {
            String err = e.getMessage();
            err = new String(err.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
            logger.info("sendEmail failure, error: ", err);
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Send email is fail, please try again");
        }
    }

    @Override
    public ResultResponse checkMail(String email) {
//        if (userRepository.existsByEmail(email)) {
//            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email is already registered!");
//        }

        String emailRegex = "\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches()) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Error: Email format is incorrect");
        }
        return ResultResponse.success();
    }

    @Override
    public ResultResponse validMail(String code, String uuid) {
        Map<Object, Object> valueMap = redisUtil.getHashEntries(uuid);
        logger.info("validMail method: redis get key:{}, value:{}", uuid, valueMap);
        if (CollectionUtils.isEmpty(valueMap)) {
            return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Verification code has expired.");
        }
        String correctCode = (String) valueMap.get(CODE);
        if (correctCode.equals(code)) {
            redisUtil.set(VERIFY + uuid, YES, EXPIRE_TIME_THIRTY, TimeUnit.MINUTES);
            logger.info("validMail method: redis set key:{}, value:{}, expireTime:{}, TimeUnit:{}", VERIFY + uuid, YES, EXPIRE_TIME_THIRTY, TimeUnit.MINUTES);
            return ResultResponse.success("Verification code is correct.");
        }
        redisUtil.set(VERIFY + uuid, NO, EXPIRE_TIME_THIRTY, TimeUnit.MINUTES);
        logger.info("validMail method: redis set key:{}, value:{}, expireTime:{}, TimeUnit:{}", VERIFY + uuid, NO, EXPIRE_TIME_THIRTY, TimeUnit.MINUTES);
        return ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), "Verification code is uncorrected.");
    }

    private Properties getProperties() {
        // 配置发送邮件的环境属性
        final Properties props = new Properties();
        // 表示SMTP发送邮件，需要进行身份验证
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        // 如果使用ssl，则去掉使用25端口的配置，进行如下配置,
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.port", SMTP_PORT);
        props.put("mail.smtp.port", SMTP_PORT);
        // 发件人的账号，填写控制台配置的发信地址,比如xxx@xxx.com
        props.put("mail.user", "18803360392@163.com");
        // 访问SMTP服务时需要提供的密码(在控制台选择发信地址进行设置)
        props.put("mail.password", "AHRUTPRRNFLQADXU");
        props.setProperty("mail.smtp.socketFactory.fallback", "false");
        props.put("mail.smtp.ssl.enable", "true");
        return props;
    }
}
