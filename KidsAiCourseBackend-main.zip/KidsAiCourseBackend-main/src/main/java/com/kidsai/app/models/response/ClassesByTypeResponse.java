package com.kidsai.app.models.response;

import com.kidsai.app.utils.enums.ClassStatus;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ClassesByTypeResponse {

    private Long id;
    private String name;
    private String location;
    private Integer available;
    private BigDecimal price;
    private ClassStatus status;
    private Boolean isDeleted;
}
