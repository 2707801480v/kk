package com.kidsai.app.models.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.kidsai.app.utils.enums.ClassStatus;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;


@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class UserCourseResponse {

    private String courseType;

    private String courseName;

    private String className;

    private BigDecimal amount;

    private ClassStatus status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "UTC")
    private Timestamp selectedClassDate;

    public UserCourseResponse(String courseType, String courseName, String className, BigDecimal amount, ClassStatus status, Date selectedClassDate) {
        this.courseType = courseType;
        this.courseName = courseName;
        this.className = className;
        this.amount = amount;
        this.status = status;
        this.selectedClassDate = selectedClassDate != null ? new Timestamp(selectedClassDate.getTime()) : null;
    }
}
