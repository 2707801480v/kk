package com.kidsai.app.controller;

import com.kidsai.app.models.request.CallAIRecordRequest;
import com.kidsai.app.service.CallAIRecordService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/callAI")
public class CallAIRecordController {

    @Autowired
    private CallAIRecordService callAIRecordService;

    @PostMapping("/save")
    public ResponseEntity<ResultResponse> save(@Validated @RequestBody CallAIRecordRequest callAIRecord) {
        ResultResponse result = callAIRecordService.save(callAIRecord);
        if (result.getCode().equals(String.valueOf(HttpStatus.OK.value()))) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.badRequest().body(result);
    }
}
