package com.kidsai.app.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kidsai.app.models.ClassEntity;
import com.kidsai.app.models.ClassSchedule;
import com.kidsai.app.models.User;
import com.kidsai.app.models.UserClass;
import com.kidsai.app.models.response.UserClassInfoResponse;
import com.kidsai.app.models.response.UserCourseResponse;
import com.kidsai.app.repository.ClassRepository;
import com.kidsai.app.repository.UserClassRepository;
import com.kidsai.app.repository.UserRepository;
import com.kidsai.app.service.UserClassService;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserClassServiceImpl implements UserClassService {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Logger logger = LoggerFactory.getLogger(UserClassServiceImpl.class);

    @Autowired
    private UserClassRepository userClassRepository;

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private UserRepository userRepository;


    @Transactional
    @Override
    public ResultResponse save(Long userId, Long classId, Boolean isDelete) {
        if (Objects.isNull(userId) || Objects.isNull(classId)) {
            return ResultResponse.error("Error: userId and classId cannot be empty.");
        }
        // check balance
        Optional<ClassEntity> classEntityOptional = classRepository.findById(classId);
        if (classEntityOptional.isEmpty()) {
            return ResultResponse.error("Error: cannot found class by classId.");
        }

        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            return ResultResponse.error("Error: cannot found user by userId.");
        }

        if (classEntityOptional.get().getPrice().compareTo(userOptional.get().getBalance()) > 0) {
            return ResultResponse.error("Error: Insufficient user balance.");
        }
        // check if the class has started
        if (isDelete) {
            ClassSchedule nextSchedule = classEntityOptional.get().getClassSchedules().stream()
                    .filter(schedule -> schedule.getClassDate().isAfter(LocalDate.now()) ||
                            (schedule.getClassDate().isEqual(LocalDate.now()) &&
                                    schedule.getStartTime().isAfter(LocalDateTime.now().toLocalTime())))
                    .min((s1, s2) -> s1.getClassDate().compareTo(s2.getClassDate()))
                    .orElse(null);

            if (nextSchedule != null) {
                LocalDateTime startDateTime = LocalDateTime.of(nextSchedule.getClassDate(), nextSchedule.getStartTime());
                LocalDateTime currentDateTime = LocalDateTime.now();
                LocalDateTime deadlineForWithdrawal = startDateTime.minusHours(24);

                if (currentDateTime.isAfter(deadlineForWithdrawal)) {
                    String errorMsg = String.format("Error: The next class starts on %s at %s and cannot be withdrawn within 24 hours before it begins.",
                            nextSchedule.getClassDate(), nextSchedule.getStartTime());
                    return ResultResponse.error(errorMsg);
                }
            }
        }

        List<UserClass> userClassList = userClassRepository.findByUserIdAndClassId(userId, classId);
        if (!userClassList.isEmpty()) {
            UserClass userClass = userClassList.get(0);
            userClass.setIsDeleted(isDelete);
            userClassRepository.save(userClass);
            if (isDelete) {
                userOptional.get().setBalance(userOptional.get().getBalance().add(classEntityOptional.get().getPrice()));
            } else {
                userOptional.get().setBalance(userOptional.get().getBalance().subtract(classEntityOptional.get().getPrice()));
            }
            userRepository.save(userOptional.get());
            return ResultResponse.success("User class record updated successfully.");
        }
        User user = new User();
        user.setId(userId);
        ClassEntity classEntity = new ClassEntity();
        classEntity.setId(classId);
        UserClass userClass = new UserClass();
        userClass.setUser(user);
        userClass.setClassEntity(classEntity);
        userClassRepository.save(userClass);
        if (isDelete) {
            userOptional.get().setBalance(userOptional.get().getBalance().add(classEntityOptional.get().getPrice()));
        } else {
            userOptional.get().setBalance(userOptional.get().getBalance().subtract(classEntityOptional.get().getPrice()));
        }
        userRepository.save(userOptional.get());
        return ResultResponse.success("New user class record created successfully.");
    }

    @Override
    public ResultResponse getTotalClassInfo(Long userId) {
        if (Objects.isNull(userId)) {
            return ResultResponse.error("Error: userId cannot be empty.");
        }
        UserClassInfoResponse response = new UserClassInfoResponse();
        Integer totalClass = userClassRepository.countTotalClassesByUserId(userId);
        Integer completedClass = userClassRepository.countCompletedClassesByUserId(userId);

        response.setUserId(userId);
        response.setTotalClass(totalClass);
        response.setCompletedClass(completedClass);
        response.setRemainingClass(Math.max(0, totalClass - completedClass));
        return ResultResponse.success(response);
    }

    @Override
    public ResultResponse getUserCoursesByUserId(Long userId) {
        if (Objects.isNull(userId)) {
            return ResultResponse.error("Error: userId cannot be empty.");
        }
        List<UserCourseResponse> responseList = userClassRepository.getUserCourseAndClassInfo(userId);
        return ResultResponse.success(responseList);
    }

    @Override
    public ResultResponse getUserClassesByUserIdAndDate(Long userId, LocalDate startDate, LocalDate endDate) {
        if (Objects.isNull(userId)) {
            return ResultResponse.error("Error: userId cannot be empty.");
        }
        if (Objects.isNull(startDate) || Objects.isNull(endDate)) {
            return ResultResponse.error("Error: date cannot be empty.");
        }

//        List<ClassEntity> responseList = userClassRepository.getUserClassesByUserIdAndDate(userId, startDate, endDate);
//        if (responseList.isEmpty()) {
//            return ResultResponse.success("No classes found for the given user id and date");
//        }
//
//        List<ClassResponse> classResponseList = responseList.stream().map(r -> {
//            ClassResponse response = new ClassResponse();
//            response.setId(r.getId());
//            response.setCourseId(r.getCourse().getId());
//            response.setName(r.getName());
//            response.setAvailable(r.getAvailable());
//            response.setPrice(r.getPrice());
//            response.setLocation(r.getLocation());
//
//            List<ClassScheduleResponse> schedules = r.getClassSchedules().stream()
//                    .filter(schedule -> !schedule.getClassDate().isBefore(startDate) && !schedule.getClassDate().isAfter(endDate))
//                    .map(schedule -> new ClassScheduleResponse(
//                            schedule.getClassDate(),
//                            schedule.getStartTime().toString().substring(0, 5),
//                            schedule.getEndTime().toString().substring(0, 5)
//                    ))
//                    .collect(Collectors.toList());
//            response.setSchedules(schedules);
//
//            return response;
//        }).collect(Collectors.toList());
//
//        ResultResponse result = ResultResponse.success(classResponseList);
//
//        try {
//            String resultString = objectMapper.writeValueAsString(result);
//            logger.info("Response: {}", resultString);
//        } catch (JsonProcessingException e) {
//            logger.error("Error serializing response", e);
//        }
//        return result;

        return null;
    }
}
