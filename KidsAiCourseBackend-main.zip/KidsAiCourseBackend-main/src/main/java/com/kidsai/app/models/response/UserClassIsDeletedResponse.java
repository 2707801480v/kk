package com.kidsai.app.models.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class UserClassIsDeletedResponse {
    private Boolean isDeleted;
    private Long userClassId;
}
