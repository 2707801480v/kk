package com.kidsai.app.repository;

import com.kidsai.app.models.CallAIRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CallAIRecordRepository extends JpaRepository<CallAIRecord, Long> {

}
