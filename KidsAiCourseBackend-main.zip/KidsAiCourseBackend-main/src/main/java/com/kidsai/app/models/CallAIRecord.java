package com.kidsai.app.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "call_ai_record")
@Getter
@Setter
@NoArgsConstructor
public class CallAIRecord extends BaseEntity {

    private Long userId;

    @NotBlank
    private String endpoint;

    @NotBlank
    private String API;

    private String prompt;
}
