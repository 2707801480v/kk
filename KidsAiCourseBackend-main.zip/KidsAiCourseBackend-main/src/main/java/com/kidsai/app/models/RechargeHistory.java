package com.kidsai.app.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "recharge_history")
@Getter
@Setter
@NoArgsConstructor
public class RechargeHistory extends BaseEntity {


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "recharge_amount")
    private BigDecimal rechargeAmount;
}
