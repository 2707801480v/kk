package com.kidsai.app.models.request;

import com.kidsai.app.models.Course;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClassRequest {
    private String name;
    private String location;
    private BigDecimal price;
    private Long courseId;
    private Integer available;
}
