package com.kidsai.app.utils.enums;

public enum Role {
    STUDENT(0),
    PARENT(1);

    private final int value;

    Role(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}

