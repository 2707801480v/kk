package com.kidsai.app.models.request;

import com.kidsai.app.utils.enums.RepeatFrequencyEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClassScheduleSaveRequest {
    private Long classId;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private Integer available;
    private Integer repeatFrequency;
    private LocalDate repeatEndDate;

    public RepeatFrequencyEnum getRepeatFrequencyEnum() {
        if (this.repeatFrequency == null) {
            return null;
        }
        try {
            return RepeatFrequencyEnum.getByCode(this.repeatFrequency);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid repeat frequency code: " + this.repeatFrequency);
        }
    }

    public void setRepeatFrequency(Integer repeatFrequency) {
        this.repeatFrequency = repeatFrequency;
    }
}
