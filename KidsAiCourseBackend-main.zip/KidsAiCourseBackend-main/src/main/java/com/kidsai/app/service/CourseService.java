package com.kidsai.app.service;

import com.kidsai.app.models.request.CourseRequest;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

public interface CourseService {
    ResultResponse findCoursesByType(Long courseTypeId);

    ResultResponse save(CourseRequest courseRequest);

    ResultResponse findCoursesByName(String name);

    ResultResponse findAll();

    ResultResponse findStatusList();

    ResultResponse saveStatus(Long courseId, Integer status);

    ResultResponse delete(Long id);

    ResultResponse editCourse(Long id, CourseRequest courseRequest);

    ResultResponse searchCourses(Long courseTypeId, Integer status);

    ResultResponse findById(Long id);

}
