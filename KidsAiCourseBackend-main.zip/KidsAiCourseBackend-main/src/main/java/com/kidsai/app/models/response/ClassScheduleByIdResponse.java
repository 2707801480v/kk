package com.kidsai.app.models.response;

import com.kidsai.app.models.request.ClassScheduleRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClassScheduleByIdResponse {

    private Long classId;

    public List<ClassScheduleByIdResponse.ScheduleItem> scheduleItems;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ScheduleItem {

        @NotNull
        private Long id;

        @NotNull
        private LocalDate date;

        @NotNull
        private LocalTime startTime;

        @NotNull
        private LocalTime endTime;

        private Integer available;
    }
}
