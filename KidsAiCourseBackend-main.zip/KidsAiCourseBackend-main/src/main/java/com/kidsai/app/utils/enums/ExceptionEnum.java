package com.kidsai.app.utils.enums;

import com.kidsai.app.utils.exceptions.BaseErrorInfoInterface;

public enum ExceptionEnum implements BaseErrorInfoInterface {
    // Data operation error definition
    SUCCESS("2000", "success"),
    BODY_NOT_MATCH("4000", "The requested data format does not match."),
    SIGNATURE_NOT_MATCH("4001", "The requested digital signature does not match."),
    NOT_FOUND("4004", "The resource was not found."),
    INTERNAL_SERVER_ERROR("5000", "Server internal error."),
    SERVER_BUSY("5003", "Server is busy. Please try later.");

    private final String resultCode;

    private final String resultMsg;

    ExceptionEnum(String resultCode, String resultMsg) {
        this.resultCode = resultCode;
        this.resultMsg = resultMsg;
    }

    @Override
    public String getResultCode() {
        return resultCode;
    }

    @Override
    public String getResultMsg() {
        return resultMsg;
    }
}
