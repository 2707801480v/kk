package com.kidsai.app.aspect;

import com.kidsai.app.models.response.LoginResponse;
import com.kidsai.app.service.impl.UserDetailsImpl;
import com.kidsai.app.utils.exceptions.ResultResponse;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Aspect
@Component
public class AuthControllerAspect {

    private static final Logger logger = LoggerFactory.getLogger(AuthControllerAspect.class);

    @Pointcut("execution(* com.kidsai.app.controller.AuthController.*(..))")
    public void authControllerPointcut() {
    }

    @AfterReturning(pointcut = "authControllerPointcut()", returning = "result")
    public void logUserActions(JoinPoint joinPoint, ResponseEntity<?> result) {
        if (result.getBody() instanceof LoginResponse) {
            logCommonInfoUser("User authenticated successfully: {}");
        } else if (result.getBody() instanceof ResultResponse resultResponse) {
            String methodName = joinPoint.getSignature().getName();
            if (isSuccessfulResponse(resultResponse)) {
                switch (methodName) {
                    case "logout" -> logCommonInfoUser("User logged out successfully: {}");
                    case "changePassword" -> logCommonInfoUser("User changed password successfully: {}");
                    case "forgotPassword" -> logCommonInfoUser("User forgot password successfully: {}");
                    case "resetPassword" -> logCommonInfoUser("User reset password successfully: {}");
                    case "registerUser" -> logCommonInfoUser("User register successfully: {}");
                }
            }
        }
    }

    private boolean isSuccessfulResponse(ResultResponse resultResponse) {
        return resultResponse.getCode().equals(String.valueOf(HttpStatus.OK.value()));
    }

    private void logCommonInfoUser(String info) {
        Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
                .map(Authentication::getPrincipal)
                .filter(UserDetailsImpl.class::isInstance)
                .map(UserDetailsImpl.class::cast)
                .ifPresent(userDetails -> logger.info(info, userDetails.getEmail()));

    }
}
