package com.kidsai.app.models.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@ToString
public class ResetPasswordRequest {

    @NotBlank
    private String email;

    @NotBlank
    private String validCode;

    @NotBlank
    private String newPassword;

    @NotBlank
    private String confirmPassword;

    @NotBlank
    private String uuid;
}
