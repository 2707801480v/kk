package com.kidsai.app.utils.exceptions;

public interface BaseErrorInfoInterface {

    /**
     * @return result code
     */
    String getResultCode();

    /**
     * @return result message
     */
    String getResultMsg();
}
