package com.kidsai.app.utils.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Custom global exception handling
 */
@ControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handle custom business exceptions
     *
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = BizException.class)
    @ResponseBody
    public ResponseEntity<ResultResponse> bizExceptionHandler(HttpServletRequest req, BizException e) {
        logger.error("A business exception occurred, due to:{}", e.getErrorMsg());
        return new ResponseEntity<>(ResultResponse.error(e.getErrorCode(), e.getErrorMsg()), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Other exceptions
     *
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ResponseEntity<ResultResponse> exceptionHandler(HttpServletRequest req, Exception e) {
        logger.error("Unknown exception, due to:", e);
        return new ResponseEntity<>(ResultResponse.error(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(BadCredentialsException.class)
    @ResponseBody
    public ResponseEntity<ResultResponse> handleBadCredentialsException(HttpServletRequest req, BadCredentialsException e) {
        logger.error("BadCredentialsException, due to:", e);
        return new ResponseEntity<>(ResultResponse.error(String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Login failed: Email or password is incorrect."), HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResultResponse> notValid(MethodArgumentNotValidException ex, HttpServletRequest request) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage()));

        return new ResponseEntity<>(ResultResponse.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), errors.toString()), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ResultResponse> handleAccessDeniedException(AccessDeniedException ex) {
        return new ResponseEntity<>(ResultResponse.error(String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Access Denied!"), HttpStatus.UNAUTHORIZED);
    }
}
