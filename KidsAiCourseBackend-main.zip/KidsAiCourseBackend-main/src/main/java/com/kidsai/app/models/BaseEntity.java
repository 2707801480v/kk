package com.kidsai.app.models;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

@Getter
@Setter
@MappedSuperclass
@ToString
public class BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "gmt_create")
    private Timestamp gmtCreate;

    @Column(name = "gmt_update")
    private Timestamp gmtUpdate;

    @PrePersist
    protected void onCreate() {
        this.gmtCreate = Timestamp.from(LocalDateTime.now()
                .truncatedTo(ChronoUnit.MINUTES)
                .atZone(ZoneId.systemDefault())
                .toInstant());
    }

    @PreUpdate
    protected void onUpdate() {
        this.gmtUpdate = Timestamp.from(LocalDateTime.now()
                .truncatedTo(ChronoUnit.MINUTES)
                .atZone(ZoneId.systemDefault())
                .toInstant());
    }
}
